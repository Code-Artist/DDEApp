//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "ClientControl_Item.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFClientControlItem *FClientControlItem = NULL;
//---------------------------------------------------------------------------
__fastcall TFClientControlItem::TFClientControlItem(TComponent* Owner,
	AnsiString ClientName, int ClientHandle)
	: TForm(Owner)
{
    Parent = (TWinControl *)Owner;
	Bt_Control->Caption = ClientName;
	ddeHandle = ClientHandle;

	ClientMessages = new TFClientMessages(Owner, ClientName);
}
//---------------------------------------------------------------------------
void __fastcall TFClientControlItem::FormDestroy(TObject *Sender)
{
	delete ClientMessages; ClientMessages = NULL;
}
//---------------------------------------------------------------------------
void TFClientControlItem::Flash_TXIndicator(void)
{
	TXTimer->Enabled = false;
	Ind_Tx->Brush->Color = clLime;
	TXTimer->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFClientControlItem::TXTimerTimer(TObject *Sender)
{
	TXTimer->Enabled = false;
	Ind_Tx->Brush->Color = clGreen;
}
//---------------------------------------------------------------------------
void TFClientControlItem::Flash_RXIndicator(void)
{
	RXTimer->Enabled = false;
	Ind_Rx->Brush->Color = clLime;
	RXTimer->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFClientControlItem::RXTimerTimer(TObject *Sender)
{
	RXTimer->Enabled = false;
	Ind_Rx->Brush->Color = clGreen;
}
//---------------------------------------------------------------------------
void __fastcall TFClientControlItem::Bt_ControlClick(TObject *Sender)
{
	if(OnClientClick) OnClientClick(this);
}
//---------------------------------------------------------------------------
void TFClientControlItem::DisableAllControl()
{
	for(int x=0; x < ControlCount; x++) Controls[x]->Enabled = false;
	for(int x=0; x < PN_Indicator->ControlCount; x++) PN_Indicator->Controls[x]->Enabled = false;
}


