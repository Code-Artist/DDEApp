//---------------------------------------------------------------------------

#ifndef DDE_ControlPanelH
#define DDE_ControlPanelH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TFDDEControlPanel : public TForm
{
__published:	// IDE-managed Components
	TGroupBox *GroupBox1;
	TComboBox *CbFunctions;
	TEdit *EdFuncParam;
	TLabel *Label1;
	TButton *BtExecuteFunction;
	TGroupBox *GroupBox2;
	TButton *BtShutDown;
	TButton *BtDisconnect;
	TGroupBox *GroupBox3;
	TComboBox *CbVariables;
	TEdit *EdVarValue;
	TLabel *Label2;
	TButton *BtVarWrite;
	TButton *BtVarRead;
	TButton *Button1;
	TOpenDialog *OpenDlg;
	void __fastcall BtExecuteFunctionClick(TObject *Sender);
	void __fastcall BtDisconnectClick(TObject *Sender);
	void __fastcall BtShutDownClick(TObject *Sender);
	void __fastcall BtVarReadClick(TObject *Sender);
	void __fastcall BtVarWriteClick(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TFDDEControlPanel(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFDDEControlPanel *FDDEControlPanel;
//---------------------------------------------------------------------------
#endif
