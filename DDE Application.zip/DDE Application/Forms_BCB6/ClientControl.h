//---------------------------------------------------------------------------

#ifndef ClientControlH
#define ClientControlH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <vector.h>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
#include "ClientControl_Item.h"
#include "DDE_ControlPanel.h"
#include "ErrorManager.h"
#include "Main_BCB6.h"
//---------------------------------------------------------------------------
class TFClientControl : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TButton *BtClearClient;
	TButton *BtAddClient;
	TScrollBox *Sb_Clients;
	TOpenDialog *DlgOpenEXE;
	void __fastcall BtAddClientClick(TObject *Sender);
	void __fastcall BtClearClientClick(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);

private:	// User declarations
	MErrorControl *Err;
	AnsiString DecodeErrorMsg(int ERRORID, int STATUS);

	TStringList *DDEBuffer;
	TFClientControlItem *ptrItem;

	void ClientItemClick(TFClientControlItem *SenderForm);
	void ClientLinkClosed(int ClientHandle);
	void ClientMessageSent(DDEHANDLE ClientHandle, TStrings *Lines);
	void ClientMessageReceived(DDEHANDLE ClientHandle, AnsiString Message);
	void ClientFunctionReturn(DDEHANDLE ClientHandle, int Status, AnsiString Message);
	void ClientDebugMessage(DDEHANDLE ClientHandle, AnsiString Message);

public:		// User declarations
	__fastcall TFClientControl(TComponent* Owner);
	void ShutDownAllClient(void);
	int AddDDEClientItem(AnsiString DDEApplication);
	TFClientControlItem *FindClientControl(int ClientHandle);

	vector <TFClientControlItem *> Items;
	int SelectedClientHandle;
	TFClientControlItem *SelectedClientControl;
};
//---------------------------------------------------------------------------
extern PACKAGE TFClientControl *FClientControl;
//---------------------------------------------------------------------------
#endif
