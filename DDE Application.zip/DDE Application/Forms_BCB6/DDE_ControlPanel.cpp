//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "DDE_ControlPanel.h"
#include "Main_BCB6.h"
#include "ClientControl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFDDEControlPanel *FDDEControlPanel;
//---------------------------------------------------------------------------
__fastcall TFDDEControlPanel::TFDDEControlPanel(TComponent* Owner)
	: TForm(Owner)
{
	EdFuncParam->Clear();
	CbFunctions->Clear();
    CbVariables->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TFDDEControlPanel::BtExecuteFunctionClick(TObject *Sender)
{
	if(CbFunctions->Text.IsEmpty() == true) return;
	if(FClientControl->SelectedClientHandle == NULL) return;

	AnsiString tFuncCmd = CbFunctions->Text + " " + EdFuncParam->Text;
	if(DDEClients->FunctionCall(FClientControl->SelectedClientHandle, tFuncCmd) != NULL)
	{
		ErrorManager->GetAllMessages(ErrReport);
		FClientControl->SelectedClientControl->ClientMessages->AddErrorMessages(ErrReport);
	}
	CbFunctions->SelectAll();
	CbFunctions->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TFDDEControlPanel::Button1Click(TObject *Sender)
	{ if(OpenDlg->Execute() == true) EdFuncParam->Text = EdFuncParam->Text + AnsiQuotedStr(OpenDlg->FileName,'"'); }
//---------------------------------------------------------------------------
void __fastcall TFDDEControlPanel::BtDisconnectClick(TObject *Sender)
{
	if(FClientControl->SelectedClientHandle == NULL) return;

	if(DDEClients->Disconnect(FClientControl->SelectedClientHandle) != NULL)
	{
		ErrorManager->GetAllMessages(ErrReport);
		FClientControl->SelectedClientControl->ClientMessages->AddErrorMessages(ErrReport);
	}
}
//---------------------------------------------------------------------------
void __fastcall TFDDEControlPanel::BtShutDownClick(TObject *Sender)
{
	if(FClientControl->SelectedClientHandle == NULL) return;

	if(DDEClients->ShutDownServer(FClientControl->SelectedClientHandle) != NULL)
	{
		ErrorManager->GetAllMessages(ErrReport);
		FClientControl->SelectedClientControl->ClientMessages->AddErrorMessages(ErrReport);
	}
}
//---------------------------------------------------------------------------
void __fastcall TFDDEControlPanel::BtVarReadClick(TObject *Sender)
{
	if(CbVariables->Text.IsEmpty() == true) return;
	if(FClientControl->SelectedClientHandle == NULL) return;

	AnsiString tVarValue;
	if(DDEClients->VariableRead(FClientControl->SelectedClientHandle, CbVariables->Text, &tVarValue) != NULL)
	{
		ErrorManager->GetAllMessages(ErrReport);
		FClientControl->SelectedClientControl->ClientMessages->AddErrorMessages(ErrReport);
	}
	EdVarValue->Text = tVarValue;
    CbVariables->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TFDDEControlPanel::BtVarWriteClick(TObject *Sender)
{
	if(CbVariables->Text.IsEmpty() == true) return;
	if(FClientControl->SelectedClientHandle == NULL) return;

	if(DDEClients->VariableWrite(FClientControl->SelectedClientHandle, CbVariables->Text, EdVarValue->Text) != NULL)
	{
		ErrorManager->GetAllMessages(ErrReport);
		FClientControl->SelectedClientControl->ClientMessages->AddErrorMessages(ErrReport);
	}
    CbVariables->SelectAll();
}
//---------------------------------------------------------------------------


