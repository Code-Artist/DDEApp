//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "ClientControl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFClientControl *FClientControl;
//---------------------------------------------------------------------------
__fastcall TFClientControl::TFClientControl(TComponent* Owner)
	: TForm(Owner)
{
	Err = new MErrorControl("Client Control");
	Err->DecodeErrorMsg = DecodeErrorMsg;

	DDEClients->OnLinkClosed = ClientLinkClosed;
	DDEClients->OnReceive_Filtered = ClientMessageReceived;
	DDEClients->OnSend = ClientMessageSent;
	DDEClients->OnFunctionReturn = ClientFunctionReturn;
	DDEClients->OnDbgMsg = ClientDebugMessage;

	DDEBuffer = new TStringList;
	DDEBuffer->DelimitedText = ' ' ;

	Caption = "DDE Clients";
	Items.clear();

	SelectedClientHandle = NULL;
	SelectedClientControl = NULL;
}
//---------------------------------------------------------------------------
void __fastcall TFClientControl::FormDestroy(TObject *Sender)
{
    delete DDEBuffer; DDEBuffer = NULL;
	delete Err; Err = NULL;
}
//---------------------------------------------------------------------------
AnsiString TFClientControl::DecodeErrorMsg(int ERRORID, int STATUS)
{
	if(ERRORID == Err->ErrorID)
	{
		switch(STATUS)
		{
            case -1: return AnsiString("File not found!\n[%1]");
			default: return AnsiString("Unknown Error!");
		}
	}
	else return AnsiString("Unknown Error. ERROR ID Not belong to this class!");
}
//---------------------------------------------------------------------------
void __fastcall TFClientControl::BtAddClientClick(TObject *Sender)
{
	if(DlgOpenEXE->Execute() == true) AddDDEClientItem(DlgOpenEXE->FileName);
	ErrorManager->Properties.ShowErrorMessage = true;
	ErrorManager->GetAllMessages();
	ErrorManager->Properties.ShowErrorMessage = false;
}
//---------------------------------------------------------------------------
void __fastcall TFClientControl::BtClearClientClick(TObject *Sender)
{
	int tID = Application->MessageBoxA("Are you sure to remove all DDE Applications?", "Comfirm Remove",
		MB_OKCANCEL | MB_ICONINFORMATION);

	if(tID == IDCANCEL) return;

	for(unsigned int x=0; x < Items.size(); x++)
		delete Items.at(x);
	Items.clear();

	//Recreate DDE Client
	DDEClients->ShutDownAllServer();
	DDEClients->DeleteAll();
}
//---------------------------------------------------------------------------
int TFClientControl::AddDDEClientItem(AnsiString DDEApplication)
{
	int tHandle;
	static AnsiString tFuncName = "AddDDEClientItem";

	//Add DDE Client Item
	Err->GpStatus = DDEClients->Add(&tHandle, DDEApplication, true); //Auto Connect
	if(Err->GpStatus < 0) return Err->GpStatus;

	//Create Visual Components for newly added Client
	TFClientControlItem *ptr = new TFClientControlItem(Sb_Clients, DDEClients->GetServiceName(tHandle), tHandle);
	ptr->Top = ptr->Height * Items.size() + 1;
	ptr->OnClientClick = ClientItemClick;

	Items.push_back(ptr);

	if(FileExists(DDEApplication) == false)
	{
		ptr->DisableAllControl();
		return Err->RaiseError(-1, tFuncName, DDEApplication);
	}
	return Err->GpStatus;
}
//---------------------------------------------------------------------------
void TFClientControl::ClientItemClick(TFClientControlItem *SenderForm)
{
	//Unhighlight all DDE Client Items
	for(unsigned int x=0; x < Items.size(); x++)
	{
		if(Items.at(x)->Ind_Select->Brush->Color == clLime)
			Items.at(x)->Ind_Select->Brush->Color = clGreen;
		if(Items.at(x)->Ind_Select->Brush->Color == clRed)
			Items.at(x)->Ind_Select->Brush->Color = clMaroon;
		if(Items.at(x)->ddeHandle == SenderForm->ddeHandle)
		{
			SelectedClientHandle = Items.at(x)->ddeHandle;
			SelectedClientControl = Items.at(x);
			FDDEControlPanel->Show();
			FDDEControlPanel->ManualDock(FDDEMain->DockPanel_Left, NULL, alBottom);
		}
	}
    Application->ProcessMessages();

	//Hightlight selected items
	SenderForm->Ind_Select->Brush->Color = clLime;
	SenderForm->ClientMessages->BringToFront();

	//Attempt to Connect to Server if Connection is not yet established
	if(DDEClients->GetConnectStatus(SenderForm->ddeHandle) == false)
	{
		if(DDEClients->Connect(SenderForm->ddeHandle) != NULL)
		{
			SenderForm->Ind_Select->Brush->Color = clRed;
			ErrorManager->GetAllMessages(ErrReport);
            SenderForm->ClientMessages->AddErrorMessages(ErrReport);
			return;
		}
		else
		{
            SenderForm->Ind_Select->Brush->Color = clLime;
        }
	}

	//Update DDE Control Panel with Selected Object
	FDDEControlPanel->CbFunctions->Clear();
	FDDEControlPanel->CbVariables->Clear();

	AnsiString tResult;
	//Get Registered Functions
	Err->GpStatus = DDEClients->VariableRead(SenderForm->ddeHandle, "FunctionList", &tResult);
	DDEBuffer->DelimitedText = tResult;
	if(Err->GpStatus == NULL)
	{
		for(int x=0; x < DDEBuffer->Count; x++)
			FDDEControlPanel->CbFunctions->Items->Add(DDEBuffer->Strings[x]);
	}
	else
	{
		ErrorManager->GetAllMessages(ErrReport);
		SenderForm->ClientMessages->AddErrorMessages(ErrReport);
	}

	//Get Registered Variables
	Err->GpStatus = DDEClients->VariableRead(SenderForm->ddeHandle, "VariableList", &tResult);
	DDEBuffer->DelimitedText = tResult;
	if(Err->GpStatus == NULL)
	{
		for(int x=0; x < DDEBuffer->Count; x++)
			FDDEControlPanel->CbVariables->Items->Add(DDEBuffer->Strings[x]);
	}
	else
	{
		ErrorManager->GetAllMessages();
		SenderForm->ClientMessages->AddErrorMessages(ErrReport);
	}

}
//---------------------------------------------------------------------------
void TFClientControl::ShutDownAllClient(void)
{
	for(unsigned int x=0; x < Items.size(); x++)
		DDEClients->ShutDownServer(Items.at(x)->ddeHandle);
}
//---------------------------------------------------------------------------
// MDDEApp_Client Events
//---------------------------------------------------------------------------
TFClientControlItem *TFClientControl::FindClientControl(int ClientHandle)
{
	for(unsigned int x=0; x < Items.size(); x++)
	{
		if(Items.at(x)->ddeHandle == ClientHandle)
			return Items.at(x);
	}
	return NULL; //Not Found
}
//---------------------------------------------------------------------------
void TFClientControl::ClientLinkClosed(int ClientHandle)
{
	ptrItem = FindClientControl(ClientHandle);
	if(ptrItem == NULL) return;

	if(ptrItem->ddeHandle == SelectedClientHandle)
		ptrItem->Ind_Select->Brush->Color = clRed;
	else
		ptrItem->Ind_Select->Brush->Color = clMaroon;
}
//---------------------------------------------------------------------------
void TFClientControl::ClientMessageSent(DDEHANDLE ClientHandle, TStrings *Lines)
{
	ptrItem = FindClientControl(ClientHandle);
	if(ptrItem == NULL) return;

	ptrItem->Flash_TXIndicator();
	ptrItem->ClientMessages->AddMessage(Lines);
}
//---------------------------------------------------------------------------
void TFClientControl::ClientMessageReceived(DDEHANDLE ClientHandle, AnsiString Message)
{
	ptrItem = FindClientControl(ClientHandle);
	if(ptrItem == NULL) return;

	ptrItem->Flash_RXIndicator();
	ptrItem->ClientMessages->AddMessage(Message);
}
//---------------------------------------------------------------------------
void TFClientControl::ClientFunctionReturn(DDEHANDLE ClientHandle, int Status, AnsiString Message)
{
	//Event for Function Return. (Currently not used)
	//Handled by ClientMessageReceived

	// **** FOR DEBUG ONLY ****
//	ptrItem = FindClientControl(ClientHandle);
//	if(ptrItem == NULL) return;
//
//	ptrItem->Flash_RXIndicator();
//	ptrItem->ClientMessages->AddMessage_Raw(Message);
	// ************************
}
//---------------------------------------------------------------------------
void TFClientControl::ClientDebugMessage(DDEHANDLE ClientHandle, AnsiString Message)
{
	//Event for Debug Message. Currently not used)
	//Handled by ClientMessageReceived

	// **** FOR DEBUG ONLY ****
//	ptrItem = FindClientControl(ClientHandle);
//	if(ptrItem == NULL) return;
//
//	ptrItem->Flash_RXIndicator();
//	ptrItem->ClientMessages->AddMessage_Raw(Message);
	// ************************
}

