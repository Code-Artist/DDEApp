//---------------------------------------------------------------------------
#pragma hdrstop
#include "BCB5_Support.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
AnsiString __fastcall AnsiReplaceStr(const AnsiString AText, const AnsiString AFromText, const AnsiString AToText)
{
	TReplaceFlags tFlag;
    tFlag  << rfReplaceAll;
    return StringReplace(AText, AFromText, AToText, tFlag);
}
//---------------------------------------------------------------------------
void __fastcall SetDelimitedText(const AnsiString Source, TStringList *Dest, const char Delimiter)
{
    //Empty Check
	if(Dest == NULL) return;
    Dest->Clear();
    if(Source.IsEmpty() == true) return;

	//Local Variables
	int DPos, QPos;
	static char QuoteChar = '\"';
	bool FlgQuotedMsg = false;

	AnsiString tTemp = Source;
	while(tTemp.IsEmpty() == false)
    {
        //Locate Symbol
        DPos = tTemp.Pos(Delimiter);
		QPos = tTemp.Pos(QuoteChar);

		//Delete Leading Delimiter
        if(DPos == 1){ tTemp.Delete(1,1); continue; }

		if((QPos != 0) && ((DPos > QPos) || (DPos == 0)))
		{
			//Found 1st Quote
			tTemp.Delete(1, QPos);
			if((QPos = tTemp.Pos(QuoteChar)) == NULL)
			{
				//Break on error
				break;
			}
			FlgQuotedMsg = true;
		}
		if(FlgQuotedMsg == false)
		{
			if(DPos > 0)
			{
				//Process Delimited param
				Dest->Add(tTemp.SubString(1, DPos - 1));
				tTemp.Delete(1, DPos);
			}
			else
			{
				//Process Last Param
				Dest->Add(tTemp);
				tTemp = "";
			}
		}
		else
        {
			//Process Quoted String, delimiter included as part of string
			Dest->Add(tTemp.SubString(1, QPos - 1));
			tTemp.Delete(1, QPos);
			FlgQuotedMsg = false; //Complete process Quoted Message
		}
	}//While
}
//---------------------------------------------------------------------------
AnsiString __fastcall GetDelimitedText(TStringList *Source, const char Delimiter)
{
	AnsiString tResult= "";
    AnsiString tSourceItem;
    for(int x=0; x < Source->Count - 1; x++)
    {
    	tSourceItem = Source->Strings[x];
    	if(tSourceItem.AnsiPos(Delimiter) != 0)
        	AnsiQuotedStr(tSourceItem, '"');

    	tResult = tResult + tSourceItem + Delimiter;
    }
    tResult = tResult + Source->Strings[Source->Count - 1];
	return tResult;
}
//---------------------------------------------------------------------------

