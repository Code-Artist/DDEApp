//---------------------------------------------------------------------------
#ifndef ErrorManagerH
#define ErrorManagerH
//---------------------------------------------------------------------------
#include <vcl.h>
#include <map.h>
#include <vector.h>
#include "CompilerVersion.h"
//---------------------------------------------------------------------------
#ifndef COMPILER_BCB5
	#include <StrUtils.hpp>
#else
	#include "BCB5_Support.h"
#endif
//---------------------------------------------------------------------------
// ERROR DATA STRUCTURE
//---------------------------------------------------------------------------
struct MErrorItem
{
	MErrorItem() { Variables = new TStringList; }
	~MErrorItem() { delete Variables; Variables = NULL; }
	int GpStatus;
	int Status;
    bool IsOSError; //Used by Error Manager to differentiate error type
	TStringList *Variables;

	//Detailed Information
	AnsiString FuncName;
	TDateTime TimeStamp;
};
enum DMsgType{ etError, etWarning, etInfo };
struct MErrorReport
{
	MErrorReport(){ Items.clear(); };
	~MErrorReport(){ ClearItems(); };
	struct MErrorReportItems
	{
		AnsiString Date;
		AnsiString Time;
		DMsgType Type;
		int StatusCode;
		AnsiString Function;
		AnsiString Message;
	};
	vector <MErrorReportItems *> Items;
	void ClearItems(void);
};
//---------------------------------------------------------------------------
// ERROR CONTROL CLIENT MODULE
//---------------------------------------------------------------------------
class MErrorControl
{
private:
	//==== LOCAL IMPLEMENATTION ====
	// Functions and data structure declared here are used only if MErrorManager
	// is not initiated in application.
	// This is to ensure modules can be compile without in other project with
	// minimal modification.
	MErrorItem *LastError;
	int _SetError(int ERRORID, int STATUS, AnsiString FunctionName, TStringList *Params);
	int _SetOSError(int ERRORID, int ERRCODE, AnsiString FunctionName, AnsiString Param);

	//Default Error Msg Function (User override)
	AnsiString _DecodeErrorMsg(int ERRORID, int STATUS)	{ return AnsiString("Error information not available!"); };

public:
	MErrorControl(AnsiString Class_Name);
	~MErrorControl();

	//Unique ID use by Error Manager to identify error class
	TStringList *ErrParams;
	AnsiString ClassName;
	int ErrorID;

	//Var to store last raised error
	int GpStatus;
	int Status;

	void DetachFromManager(void){ SetError = _SetError; };
	int RaiseError(int STATUS, AnsiString FunctionName); //Simplified Function
	int RaiseError(int STATUS, AnsiString FunctionName, AnsiString Param);
	int RaiseError(int STATUS, AnsiString FunctionName, TStringList *Params);
	void AddGeneralInfo(AnsiString FunctionName, AnsiString Message);
    int RaiseOSError(AnsiString FunctionName, AnsiString Param);

	int(__closure *SetError)(int ERRORID, int STATUS, AnsiString FunctionName, TStringList *Params);
	int(__closure *SetOSError)(int ERRORID, int ERRCODE, AnsiString FunctioName, AnsiString Param);
	AnsiString(__closure *DecodeErrorMsg)(int ERRORID, int STATUS);

};
//---------------------------------------------------------------------------
// CENTRALIZED CONTROL MANAGER
//---------------------------------------------------------------------------
enum DErrReportSeq { esFIFO = 100, esFILO };
class MErrorManager
{
private:
	AnsiString ApplicationName;
	map <int, MErrorControl *> ErrClientMap;
	vector <MErrorItem *> ErrorQueue;

	void GetErrorMsgAtIndex(MErrorReport *Report, int Index);
	MErrorManager(AnsiString AppName);
    int ClientID;

    AnsiString __fastcall GetVersion(void);

public:
    static MErrorManager *SingleInstance(AnsiString AppName);
	~MErrorManager();

	class PROPERTIES
	{
	private:
		bool FlgShowErrorMessage; //Global Message Box Switch (set to enable message box display)
		bool FlgPromptWarning;	  //Option to show warning message (FlgShowErrorMessage must be set)
		bool FlgReturnDetailInfo; //Option to include code and time stamp
		DErrReportSeq ErrSeq;	  //Define Error Reporting Sequence.
		void __fastcall SetErrSeq(DErrReportSeq Value){ if(Value == esFILO) ErrSeq = esFILO; else ErrSeq = esFIFO; };

	public:
		__property bool ShowErrorMessage = {read = FlgShowErrorMessage, write = FlgShowErrorMessage};
		__property bool PromptWarning = {read = FlgPromptWarning, write = FlgPromptWarning};
		__property bool ReturnDetailInfo = {read = FlgReturnDetailInfo, write = FlgReturnDetailInfo};
		__property DErrReportSeq ErrorReportSeq = { read = ErrSeq, write = SetErrSeq };
	}Properties;

	//Error Client Registration Control
	int RequestUniqueErrorID(MErrorControl *ClientHandle);
	void UnregisterClient(MErrorControl *ClientHandle);

	//Queue Control
	void FlushQueue(void); //Delete all logged messages
	void GetAllMessages(void);
	void GetAllMessages(MErrorReport *Report);

	//Raise Error, Add to Queue
	int SetError(int ERRORID, int STATUS, AnsiString FunctionName, TStringList *Params);
	int SetOSError(int ERRORID, int ERRCODE, AnsiString FunctionName, AnsiString Param);
	int CheckStatus(void);

    __property AnsiString Version = {read = GetVersion }; //Return version when distributed in library form
};
//---------------------------------------------------------------------------
extern MErrorManager *ErrorManager;
//---------------------------------------------------------------------------
#endif

