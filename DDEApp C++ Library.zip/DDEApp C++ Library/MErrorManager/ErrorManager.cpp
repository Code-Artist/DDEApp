//---------------------------------------------------------------------------
#pragma hdrstop
#include "ErrorManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
const int DEFClientIDStep = -10;
const int ClientIDStart = -100;
int LocalClientID = -1000;
const static AnsiString _Version = "2.1.2";
//---------------------------------------------------------------------------
// Shared Private Function
//---------------------------------------------------------------------------
AnsiString GetOSErrMsg(int OSErrCode)
{
	/************************************************************************
	 DESC	: Get operating system error message
	 RETURN : Error message string.
	************************************************************************/

	LPTSTR tOSErrMsg;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, OSErrCode, NULL, (LPTSTR)&tOSErrMsg, NULL, NULL);
	return tOSErrMsg;
}
//---------------------------------------------------------------------------
// CLASS: Error Report
//---------------------------------------------------------------------------
void MErrorReport::ClearItems(void)
{
	/************************************************************************
	 DESC	: Clear all items in error report.
	************************************************************************/
	for(unsigned int x=0; x < Items.size(); x++)
		delete Items.at(x);
	Items.clear();
}
//---------------------------------------------------------------------------
// CLASS: ERROR CONTROL CLIENT
//---------------------------------------------------------------------------
MErrorControl::MErrorControl(AnsiString Class_Name)
{
	/************************************************************************
	 DESC	: Constructor
	 ------------------------------------------------------------------------
	 > With MErrorManager:
		Register and request unique ErrorID from MErrorManager.
		Use centralized SetError() function.

	 > Without MErrorManager:
		Set default Error ID. Create data structure to store
		Last Error.
	************************************************************************/

	if(ErrorManager != NULL)
	{
		//Setup client link with Error Manager
		ErrorID = ErrorManager->RequestUniqueErrorID(this);
		SetError = ErrorManager->SetError;
	    SetOSError = ErrorManager->SetOSError;
		LastError = NULL;
	}
	else
	{
		//Default Configuration if ErrorManager not initiated
        LocalClientID += DEFClientIDStep;
		ErrorID = LocalClientID; //Default Error ID if Error Manager is not used.
		SetError = _SetError;
		SetOSError = _SetOSError;
		LastError = new MErrorItem;
	}

	//Register Class Name
	if(Class_Name.IsEmpty() == true) ClassName = "Unnamed";
	else ClassName = Class_Name;
	DecodeErrorMsg = MErrorControl::_DecodeErrorMsg;

	ErrParams = new TStringList();
	ErrParams->Clear();
}
//---------------------------------------------------------------------------
MErrorControl::~MErrorControl()
{
	/************************************************************************
	 DESC	: Destructor
	 ------------------------------------------------------------------------
	 > Unregister from centralized MErrorManager to ensure
		MErrorManager does not make a invalid call to deleted
		module.
	************************************************************************/
	delete ErrParams;
	delete LastError;
	ErrParams = NULL;
	LastError = NULL;
	if(ErrorManager != NULL) ErrorManager->UnregisterClient(this);
}
//---------------------------------------------------------------------------
int MErrorControl::_SetError(int ERRORID, int STATUS, AnsiString FunctionName, TStringList *Params)
{
	/************************************************************************
	 DESC	: Set Error (LOCAL IMPLEMENTATION)
	 RETURN : STATUS
	 ------------------------------------------------------------------------
	 NOTE:
	 - Use without MErrorManager only.
	 - Store last found error in LastError class.
	 - Error raised is pop up immediately in Message Box.

	 INPUT:
	 - ERRORID: Unique ID to indicate class that raised the error.
	 - STATUS: Error / Warning code defined by user.
	 - FunctionName: Information of function where the error is raised.
	 - Params : Additional parameter for more run-time variables.

	 OUTPUT:
	 - Stored ERRORID and STATUS in client object for local access.
	 [MErrorControl *Client]->Status = STATUS
	 [MErrorControl *Client]->GpStatus = ERRORID
	************************************************************************/

	//Store ERRORID and STATUS for local access
	GpStatus = ERRORID;
	Status = STATUS;

	LastError->GpStatus = ERRORID;
	LastError->Status = STATUS;
	LastError->IsOSError = false;
	LastError->TimeStamp = TDateTime().CurrentDateTime();
	FunctionName.IsEmpty() == true ?
		LastError->FuncName = "Unknown" :
		LastError->FuncName = FunctionName;
    if(Params) LastError->Variables->Assign(Params);

	//Show Error immediately in PopUp MessageBox
	AnsiString tMsg;
	int tMsgFlag;
	if(Status == 0) return NULL;
	if(Status < 0){ tMsg = AnsiString("[ERROR] "); tMsgFlag = MB_ICONERROR | MB_OK; }
	else{ tMsg = AnsiString("[WARNING] "); tMsgFlag = MB_ICONWARNING | MB_OK; }

	tMsg += ClassName + "::" + FunctionName + "(): " + DecodeErrorMsg(ERRORID, STATUS);

	AnsiString tFind;
	for(int x=0; x < LastError->Variables->Count; x++)
	{
		tFind = AnsiString("%") + AnsiString(x+1);
		tMsg = AnsiReplaceStr(tMsg, tFind, LastError->Variables->Strings[x]);
	}
	Application->MessageBoxA(tMsg.c_str(), ClassName.c_str(), tMsgFlag);
    return STATUS;
}
//---------------------------------------------------------------------------
int MErrorControl::_SetOSError(int ERRORID, int ERRCODE,
	AnsiString FunctionName, AnsiString Param)
{
	/************************************************************************
	 DESC	: Set operating system error. Local Implementation
	 OUTPUT : Prompt error message.
	************************************************************************/

	//Store ERRORID and STATUS
	LastError->GpStatus = GpStatus = ERRORID;
	LastError->Status = Status = ERRCODE;
	LastError->IsOSError = true;
	LastError->TimeStamp = TDateTime().CurrentDateTime();
	FunctionName.IsEmpty() == true ?
		LastError->FuncName = "Unknown" :
		LastError->FuncName = FunctionName;

	AnsiString tMsg = "[OS ERROR] ";
	tMsg += ClassName + "::" + FunctionName + "(): 0x" + IntToHex(ERRCODE, 8) +
		"\n" + GetOSErrMsg(ERRCODE);

	if(Param.IsEmpty() == false) tMsg += Param;
	ShowMessage(tMsg);
	return ERRORID;
}
//---------------------------------------------------------------------------
int MErrorControl::RaiseError(int STATUS, AnsiString FunctionName)
	{ return SetError(this->ErrorID, STATUS, FunctionName, NULL); }
//---------------------------------------------------------------------------
int MErrorControl::RaiseError(int STATUS, AnsiString FunctionName, AnsiString Param)
{
	/************************************************************************
	 DESC	: Raise Error  
	 RETURN : ERRORID 
	 ------------------------------------------------------------------------
	 NOTE:
	 - Simplfied version of SetError() where No
		additional parameter is allowed and default client ErrorID
		is used.
	 - Called to SetError with prefixed ErrorID and no Variables
	 
	 INPUT:
	 - STATUS: Error / Warning code defined by user.
	 - FunctionName: Information of function where the error is raised.

	 OUTPUT:
	 - Stored ERRORID and STATUS in client object for local access.
	 [MErrorControl *Client]->Status = STATUS
	 [MErrorControl *Client]->GpStatus = ERRORID
	************************************************************************/
	ErrParams->Clear();
	ErrParams->Text = Param;
	return SetError(this->ErrorID, STATUS, FunctionName, ErrParams);
}
//---------------------------------------------------------------------------
int MErrorControl::RaiseError(int STATUS, AnsiString FunctionName, TStringList *Params)
	{ return SetError(this->ErrorID, STATUS, FunctionName, Params); }
//---------------------------------------------------------------------------
void MErrorControl::AddGeneralInfo(AnsiString FunctionName, AnsiString Message)
{
	/************************************************************************
	 DESC	: Add General Info 
	 ------------------------------------------------------------------------
	 NOTE: Status set to NULL.
	************************************************************************/

	ErrParams->Clear();
	ErrParams->Text = Message;
	SetError(this->ErrorID, NULL, FunctionName, ErrParams);
}
//---------------------------------------------------------------------------
int MErrorControl::RaiseOSError(AnsiString FunctionName, AnsiString Param)
	{ return SetOSError(this->ErrorID, GetLastError(), FunctionName, Param); }
//---------------------------------------------------------------------------
// CLASS: ERROR MANAGER
//---------------------------------------------------------------------------
// Static Variable
MErrorManager *ErrorManager = NULL;
//---------------------------------------------------------------------------
AnsiString __fastcall MErrorManager::GetVersion(void){ return _Version; }
MErrorManager *MErrorManager::SingleInstance(AnsiString AppName)
{
	if(ErrorManager == NULL) ErrorManager = new MErrorManager(AppName);
	return ErrorManager;
}
//---------------------------------------------------------------------------
MErrorManager::MErrorManager(AnsiString AppName)
{
    ClientID = ClientIDStart;
	ApplicationName = AppName;
	Properties.ShowErrorMessage = true;
	Properties.PromptWarning = true;
	Properties.ReturnDetailInfo = true;
	Properties.ErrorReportSeq = esFIFO;
}
MErrorManager::~MErrorManager()
{
	FlushQueue();
	ErrorManager = NULL;

	map <int, MErrorControl *>::iterator ptrClientMap;
	for(ptrClientMap = ErrClientMap.begin(); ptrClientMap != ErrClientMap.end(); ptrClientMap++)
		ptrClientMap->second->DetachFromManager();
}
//---------------------------------------------------------------------------
int MErrorManager::RequestUniqueErrorID(MErrorControl *ClientHandle)
{
	/************************************************************************
	 DESC	: Request Unique Error ID 
	 RETURN : Generated Client ID 
	 ------------------------------------------------------------------------
	 INPUT: ClientHandle : Pointer of Error Client object.
	 NOTE : 
	 	- Initial Error ID and step value are defined in DEFClientIDStart
		 and DEFClientIDStep.
		- Possible to have multiple ID for each Client Handle.
	************************************************************************/

	//Return a unique ClientID for specified ClientHandle
    ClientID += DEFClientIDStep;
	ErrClientMap[ClientID] = ClientHandle;
	return ClientID;
}
//---------------------------------------------------------------------------
void MErrorManager::UnregisterClient(MErrorControl *ClientHandle)
{
	/************************************************************************
	 DESC	: Unregister Client 
	 ------------------------------------------------------------------------
	 NOTE : Call by client's destructor to unregister all Error ID.
 	 INPUT: ClientHandle : Pointer of Error Client object.
	************************************************************************/

	map <int, MErrorControl *>::iterator ptrClientMap;
	for(ptrClientMap = ErrClientMap.begin(); ptrClientMap != ErrClientMap.end(); )
	{
		if(ptrClientMap->second == ClientHandle)
		{
			ErrClientMap.erase(ptrClientMap);
			ptrClientMap = ErrClientMap.begin();
		}
		else ptrClientMap++;
	}
}
//---------------------------------------------------------------------------
// SECTION: Queue Control
//---------------------------------------------------------------------------
void MErrorManager::FlushQueue(void)
{
	/************************************************************************
	 DESC	: Flush logged messages. 
	************************************************************************/
	for(unsigned int x=0; x < ErrorQueue.size(); x++)
		delete ErrorQueue.at(x);
	ErrorQueue.clear();
}
//---------------------------------------------------------------------------
int MErrorManager::SetError(int ERRORID, int STATUS, AnsiString FunctionName, TStringList *Params)
{
	/************************************************************************
	 DESC	: Set Error
	 RETURN : STATUS
	 ------------------------------------------------------------------------
	 NOTE:
	 - Use with MErrorManager only.
	 - Function prototype must match with MErrorControl::SetError()
	 
	 INPUT:
	 - ERRORID: Unique ID to indicate class that raised the error.
	 - STATUS: Error / Warning code defined by user.
	 - FunctionName: Information of function where the error is raised.
	 - Params : Additional parameter for more run-time variables.
	 
	 OUTPUT:
	 - Stored ERRORID and STATUS in client object for local access.
	 [MErrorControl *Client]->Status = STATUS
	 [MErrorControl *Client]->GpStatus = ERRORID
	************************************************************************/

	//Add To Queue
	MErrorItem *ptr;
	ErrorQueue.push_back(new MErrorItem);
	ptr = ErrorQueue.back();

	//Store Information
	ptr->GpStatus = ERRORID;
	ptr->Status = STATUS;
	ptr->IsOSError = false;
	ptr->TimeStamp = TDateTime().CurrentDateTime();
	FunctionName.IsEmpty() == true ?
		ptr->FuncName = "Unknown" :
		ptr->FuncName = FunctionName;

	if(ErrClientMap[ERRORID] != NULL)
	{
		ErrClientMap[ERRORID]->GpStatus = ERRORID;
		ErrClientMap[ERRORID]->Status = STATUS;
	}

	//Consume Parameters
	if(Params != NULL)
	{
		for(int x=0; x < Params->Count; x++)
			ptr->Variables->Add(Params->Strings[x]);
		Params->Clear();
	}
	return STATUS;
}
//---------------------------------------------------------------------------
int MErrorManager::SetOSError(int ERRORID, int ERRCODE,
	AnsiString FunctionName, AnsiString Param)
{
	/************************************************************************
	 DESC	: Set operating system error. (Error Manager)
	************************************************************************/

	//Add To Queue
	MErrorItem *ptr;
	ErrorQueue.push_back(new MErrorItem);
	ptr = ErrorQueue.back();
	
	//Store Information
	ptr->GpStatus = ERRORID;
	ptr->Status = ERRCODE;
	ptr->IsOSError = true;
	ptr->TimeStamp = TDateTime().CurrentDateTime();
	FunctionName.IsEmpty() == true ?
		ptr->FuncName = "Unknown" :
		ptr->FuncName = FunctionName;
	
	if(ErrClientMap[ERRORID] != NULL)
	{
		ErrClientMap[ERRORID]->GpStatus = ERRORID;
		ErrClientMap[ERRORID]->Status = ERRCODE;
	}
	
	if(!Param.IsEmpty()) ptr->Variables->Add(Param);

	return ERRORID;
}
//---------------------------------------------------------------------------
void MErrorManager::GetAllMessages(void){ GetAllMessages(NULL); }
void MErrorManager::GetAllMessages(MErrorReport *Report)
{
	/************************************************************************
	 DESC	: Error Reporting - Get All Messages 
	 ------------------------------------------------------------------------
	 NOTE :
	 - Error Messages will be removed from queue and thus clear all
		the logged error.
	 - When property ShowMessageBox is set to true, Set PromptWarning
		to true to show warning message, else warning messages will
		be suppressed.
	************************************************************************/
	int tQueueSize = ErrorQueue.size();
	if(Report) Report->ClearItems();
	if(Properties.ErrorReportSeq == esFIFO)
	{
		//Error Reported in First IN First Out Sequence
		for(int x=0; x < tQueueSize; x++)
			GetErrorMsgAtIndex(Report, x);
	}
	else
	{
		//Error Reported in First IN Last Out Sequence
		for(int x = tQueueSize - 1; x >= 0; x--)
			GetErrorMsgAtIndex(Report, x);
	}
	FlushQueue(); //Remove all processed messages
}
//---------------------------------------------------------------------------
void MErrorManager::GetErrorMsgAtIndex(MErrorReport *Report, int Index)
{
	MErrorItem *pErr = NULL;
	MErrorReport::MErrorReportItems *ptrItem;

	AnsiString tMsgHeader;
	AnsiString tClassFunction;
	AnsiString tMsgContent;
	AnsiString tSearchStr;
	DMsgType tType;

	pErr = ErrorQueue.at(Index);

	//Header
	if(pErr->IsOSError == true){ tMsgHeader = AnsiString("[OS ERROR] "); tType = etError; }
	else if(pErr->Status < 0){ tMsgHeader = AnsiString("[ERROR] "); tType = etError; }
	else if(pErr->Status > 0){ tMsgHeader = AnsiString("[WARNING] "); tType = etWarning; }
	else{ tMsgHeader = AnsiString("[INFO] "); tType = etInfo; }

	//Get Class, Function and Message content
	if(ErrClientMap[pErr->GpStatus] == NULL)
	{
		//Get Class and Function Name
		tClassFunction = AnsiString("<Unknown class>::") + pErr->FuncName + "():";
		tMsgContent = AnsiString("Unknown ERROR! Unregistered Client ERROR ID!");
	}
	else
	{
		//Get Class and Function Name
		tClassFunction = ErrClientMap[pErr->GpStatus]->ClassName + "::" + pErr->FuncName + "():";

		if(pErr->IsOSError == true)
		{
			//Get OS Error Code and Message
			tMsgContent = AnsiString("(0x") + IntToHex(pErr->Status, 8) + ") " + GetOSErrMsg(pErr->Status);
			if(pErr->Variables->Count != NULL) tMsgContent += pErr->Variables->Strings[0];
		}
		else
		{
			//Get Message Content and replace variable
			tMsgContent = ErrClientMap[pErr->GpStatus]->DecodeErrorMsg(pErr->GpStatus, pErr->Status);
			for(int x=0; x < pErr->Variables->Count; x++)
			{
				tSearchStr = AnsiString("%") + AnsiString(x+1);
				tMsgContent = AnsiReplaceStr(tMsgContent, tSearchStr, pErr->Variables->Strings[x]);
			}
		}
	}

	//Add Entry to Error Report (IF Pointer is VALID)
	if(Report)
	{
		ptrItem = new MErrorReport::MErrorReportItems;
		Report->Items.push_back(ptrItem);
		ptrItem->Date = pErr->TimeStamp.DateString();
		ptrItem->Time = pErr->TimeStamp.TimeString();
		ptrItem->StatusCode = pErr->Status;
		ptrItem->Type = tType;
		ptrItem->Function = tClassFunction;
		ptrItem->Message = tMsgContent;
	}

	//Compile message for message box operation
	AnsiString tPromptMessage = tMsgHeader + tClassFunction + "\n" + tMsgContent;
	if(Properties.ReturnDetailInfo == true)
	{
		tPromptMessage += AnsiString("\n\nERROR CODE : ") + AnsiString(pErr->Status);
		tPromptMessage += AnsiString("\nTIME : ") + pErr->TimeStamp.DateTimeString();
	}

	if(Properties.ShowErrorMessage)
	{
		//Error Message
		if(pErr->Status < 0)
			Application->MessageBox(tPromptMessage.c_str(), ApplicationName.c_str(), MB_ICONERROR | MB_OK);

		//Warning Message
		else if(pErr->Status > 0)
		{
			if (Properties.PromptWarning == true)
				Application->MessageBoxA(tPromptMessage.c_str(), ApplicationName.c_str(), MB_ICONWARNING | MB_OK);
        }

		//Information
		else Application->MessageBoxA(tPromptMessage.c_str(), ApplicationName.c_str(), MB_ICONINFORMATION | MB_OK);
	}
}
//---------------------------------------------------------------------------
int MErrorManager::CheckStatus(void)
{
	/************************************************************************
	 DESC	: Check Status
	 RETURN : ERRORID (Error) / STATUS (Warning) / NULL (Queue Empty)
	 ------------------------------------------------------------------------
	 NOTE : Scan ErrorQueue for ERROR (Prio 1) or WARNING (Prio 2). 
	************************************************************************/
	if(ErrorQueue.size() == NULL) return NULL;
	MErrorItem *ptr;

	//Scan for Error
	for(int x = ErrorQueue.size() - 1; x >= 0; x--)
	{
		ptr = ErrorQueue.at(x);
		if((ptr->Status < 0) || (ptr->IsOSError == true))
			return ptr->GpStatus;
	}

	//Scan for first warning
	return ErrorQueue.back()->Status;
}
//---------------------------------------------------------------------------
