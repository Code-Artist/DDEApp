#ifndef CompilerVersionH
#define CompilerVersionH

	#if(__TURBOC__ == 0x0581) //BDS 2006
	#define COMPILER_BDS2006
	#endif

	#if(__TURBOC__ == 0x0560) //C++ Builder 6
	#define COMPILER_BCB6
	#endif

	#if(__TURBOC__ == 0x0550) //C++ Builder 5
	#define COMPILER_BCB5
	#endif
	
	//Compiler Version Older than Builder 5 are not supported
	#if (__TURBOC__ < 0x0550) 
	#error "Compiler Version too old. Use C++ Builder 5 or newer"
	#endif

#endif
