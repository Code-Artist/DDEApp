//---------------------------------------------------------------------------

#ifndef ClientMessagesH
#define ClientMessagesH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <map.h>
#include <Menus.hpp>
//---------------------------------------------------------------------------
#include "ErrorManager.h"
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TFClientMessages : public TForm
{
__published:	// IDE-managed Components
	TRichEdit *REd_Message;
	TPopupMenu *SubMenu;
	TMenuItem *MsgClear;
	TMenuItem *SaveToFile;
	TSaveDialog *FileSaveDlg;
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall REd_MessageChange(TObject *Sender);
	void __fastcall MsgClearClick(TObject *Sender);
	void __fastcall SaveToFileClick(TObject *Sender);

private:	// User declarations
	TStringList *Params;

	enum DDEMsgType { mtSystem = 10, mtFunction, mtVariable, mtProperties, mtInfo, mtError };
	map <AnsiString, DDEMsgType> DDEMsgMap;

public:		// User declarations
	__fastcall TFClientMessages(TComponent* Owner, AnsiString ClientName);

	void AddMessage(TStrings *Lines);
	void AddMessage(AnsiString MessageData);
	void AddMessage_Raw(AnsiString Message);
	void AddErrorMessages(MErrorReport *Report);
};
//---------------------------------------------------------------------------
extern PACKAGE TFClientMessages *FClientMessages;
//---------------------------------------------------------------------------
#endif
