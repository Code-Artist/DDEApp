using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Timers;
using System.Diagnostics;
using System.Runtime.Serialization;
using NDde.Server;
using NDde.Client;
using CodeArtEng.ErrorManagement;

namespace CodeArtEng.DdeApp
{
    #region [ Enum ]
    /// <summary>
    /// DdeApp Variables type
    /// </summary>
    public enum DdeVariableType 
    { 
        /// <summary>
        /// 32 bits integer
        /// </summary>
        Integer, 
        /// <summary>
        /// double floating point
        /// </summary>
        Double, 
        /// <summary>
        /// string
        /// </summary>
        String 
    };
    #endregion

    #region [ Callbacks Prototypes ]
    /// <summary>
    /// Callback: Return function result.
    /// </summary>
    /// <param name="result">function result object</param>
    public delegate void FunctionCallback(FunctionResult result);
    /// <summary>
    /// Callback: Variable read / write results.
    /// </summary>
    /// <param name="result">variable result object</param>
    public delegate void VariableAccessCallback(VariableResult result);
    /// <summary>
    /// Callback: Application shutdown request.
    /// </summary>
    public delegate void ShutdownRequestCallback();
    #endregion

    #region [ Internal Shared ]
    internal enum DdeCommandType { System, Function, Variable, Info, Error };
    /// <summary>
    /// Shared static function for internal used only.
    /// </summary>
    internal static class DdeShared
    {
        //DDE Format: <Source> <Destination> <CommandType> <Command> [Param0] ... [ParamN]

        /// <summary> Position for Param0 </summary>
        public const int ParamPos = 4;
        /// <summary> DDE Command case control </summary>
        public const bool CMP_IGNORE_CASE = true;
        /// <summary> DDE Command type cross-reference.</summary>
        public static Dictionary<string, DdeCommandType> Keywords;
        /// <summary> DDE Variable type cross-reference.</summary>
        public static Dictionary<string, DdeVariableType> Variables;
        static DdeShared()
        {
            Keywords = new Dictionary<string, DdeCommandType>();
            Keywords.Add("DDE.System", DdeCommandType.System);
            Keywords.Add("DDE.Function", DdeCommandType.Function);
            Keywords.Add("DDE.Variable", DdeCommandType.Variable);
            Keywords.Add("DDE.Info", DdeCommandType.Info);
            Keywords.Add("DDE.Error", DdeCommandType.Error);

            Variables = new Dictionary<string, DdeVariableType>();
            Variables.Add("Integer", DdeVariableType.Integer);
            Variables.Add("Double", DdeVariableType.Double);
            Variables.Add("String", DdeVariableType.String);
        }
        public static string FormatDdeMessage(string sender, string receiver, DdeCommandType type, string message)
        {
            string result = "";
            foreach (KeyValuePair<string, DdeCommandType> item in Keywords)
            {
                if (item.Value == type)
                    return result = sender + " " + receiver + " " + item.Key + " " + message;
            }
            return result;
        }
    }
    #endregion

    #region [ Exception Classes ]
    /// <summary>
    /// DdeApp General Exception
    /// </summary>
    [Serializable]
    public class DdeAppException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppException"/> class.
        /// </summary>
        public DdeAppException() { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppException"/> class.
        /// </summary>
        /// <param name="message">Exception message.</param>
        public DdeAppException(string message) : base(message) { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppException"/> class.
        /// </summary>
        /// <param name="message">Exception message.</param>
        /// <param name="inEx">Inner exception</param>
        public DdeAppException(string message, Exception inEx) : base(message, inEx) { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppException"/> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"/> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"/> that contains contextual information about the source or destination.</param>
        /// <exception cref="T:System.ArgumentNullException">
        /// The <paramref name="info"/> parameter is null.
        /// </exception>
        /// <exception cref="T:System.Runtime.Serialization.SerializationException">
        /// The class name is null or <see cref="P:System.Exception.HResult"/> is zero (0).
        /// </exception>
        protected DdeAppException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
    
    /// <summary>
    /// DdeApp Function Exception
    /// </summary>
    [Serializable]
    public class DdeAppFuncException : DdeAppException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppFuncException"/> class.
        /// </summary>
        public DdeAppFuncException() { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppFuncException"/> class.
        /// </summary>
        /// <param name="message">message.</param>
        public DdeAppFuncException(string message) : base(message) { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppFuncException"/> class.
        /// </summary>
        /// <param name="message">message.</param>
        /// <param name="innerException">Inner exception</param>
        public DdeAppFuncException(string message, Exception innerException) : base(message, innerException) { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppFuncException"/> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"/> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"/> that contains contextual information about the source or destination.</param>
        /// <exception cref="T:System.ArgumentNullException">
        /// The <paramref name="info"/> parameter is null.
        /// </exception>
        /// <exception cref="T:System.Runtime.Serialization.SerializationException">
        /// The class name is null or <see cref="P:System.Exception.HResult"/> is zero (0).
        /// </exception>
        protected DdeAppFuncException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }

    /// <summary>
    /// DdeAp Link Exception
    /// </summary>
    [Serializable]
    public class DdeAppLinkException : DdeAppException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppLinkException"/> class.
        /// </summary>
        public DdeAppLinkException() { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppLinkException"/> class.
        /// </summary>
        /// <param name="message">message.</param>
        public DdeAppLinkException(string message) : base(message) { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppLinkException"/> class.
        /// </summary>
        /// <param name="message">message.</param>
        /// <param name="innerException">Inner exception.</param>
        public DdeAppLinkException(string message, Exception innerException) : base(message, innerException) { }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppLinkException"/> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"/> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"/> that contains contextual information about the source or destination.</param>
        /// <exception cref="T:System.ArgumentNullException">
        /// The <paramref name="info"/> parameter is null.
        /// </exception>
        /// <exception cref="T:System.Runtime.Serialization.SerializationException">
        /// The class name is null or <see cref="P:System.Exception.HResult"/> is zero (0).
        /// </exception>
        protected DdeAppLinkException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
    #endregion

    #region [ Event Arguments Prototype ]
    /// <summary>
    /// Base class that provide data for DdeApp events.
    /// </summary>
    public class DdeAppEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppEventArgs"/> class.
        /// </summary>
        public DdeAppEventArgs() { Source = ""; }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppEventArgs"/> class.
        /// </summary>
        /// <param name="source">The source.</param>
        public DdeAppEventArgs(string source) { Source = source; }
        /// <summary>
        /// Application that caused this event triggered.
        /// </summary>
        public string Source { get; private set; }
    }
    /// <summary>
    /// Provide data for single DdeApp command event.
    /// </summary>
    public class DdeAppCommandEventArgs : DdeAppEventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppCommandEventArgs"/> class.
        /// </summary>
        public DdeAppCommandEventArgs() : base() { Text = ""; }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppCommandEventArgs"/> class.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="text">The text.</param>
        public DdeAppCommandEventArgs(string source, string text) : base(source) { Text = text; }
        /// <summary>
        /// Command's Content.
        /// </summary>
        public string Text { get; private set; }
    }
    /// <summary>
    /// Provide data for DdeApp Commands even.
    /// </summary>
    public class DdeAppCommandsEventArgs : DdeAppEventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppCommandsEventArgs"/> class.
        /// </summary>
        public DdeAppCommandsEventArgs() : base() { Messages = new List<string>(); }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppCommandsEventArgs"/> class.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="messages">The messages.</param>
        public DdeAppCommandsEventArgs(string source, IList<string> messages) : base(source) { Messages = messages; }
        /// <summary> Commands list </summary>
        public IList<string> Messages { get; private set; }
    }
    /// <summary>
    /// Provide data for DdeApp function execution event.
    /// </summary>
    public class DdeAppFunctionReturnEventArgs : DdeAppEventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppFunctionReturnEventArgs"/> class.
        /// </summary>
        public DdeAppFunctionReturnEventArgs() : base() { Result = new FunctionResult(); }
        /// <summary>
        /// Initializes a new instance of the <see cref="DdeAppFunctionReturnEventArgs"/> class.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="result">The result.</param>
        public DdeAppFunctionReturnEventArgs(string source, FunctionResult result)
            : base(source)
        {
            Result = result;
        }
        /// <summary>
        /// Function result.
        /// </summary>
        public FunctionResult Result { get; private set; }
    }
    #endregion  

    /// <summary>
    /// DdeApp function result class.
    /// </summary>
    public class FunctionResult
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FunctionResult"/> class.
        /// </summary>
        public FunctionResult() { Status = 0; Message = ""; }
        /// <summary>
        /// Initializes a new instance of the <see cref="FunctionResult"/> class.
        /// </summary>
        /// <param name="status">Function status.</param>
        /// <param name="message">Returned message / Error message.</param>
        public FunctionResult(int status, string message) { Status = status; Message = message; }
        /// <summary> 
        /// Executed function.
        /// </summary>
        public string Function { get; set; }
        /// <summary>
        /// Load function parameters
        /// </summary>
        internal void SetFunctionParameters(List<string> paramList){ Parameters = paramList; }
        /// <summary>
        /// Function parameters
        /// </summary>
        public IList<string> Parameters { get; private set;}
        /// <summary>
        /// Returned function status.
        /// </summary>
        public int Status { get; set; }
        /// <summary>
        /// Returned function message / error message if failed.
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// Client application who triggered this function.
        /// </summary>
        public string Client { get; set; }
    }

    /// <summary>
    /// DdeApp variable result class.
    /// </summary>
    public class VariableResult
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="VariableResult"/> class.
        /// </summary>
        /// <param name="name">Variable name.</param>
        /// <param name="type">Variable type.</param>
        public VariableResult(string name, DdeVariableType type){ Name = name; VariableType = type; Value = ""; }
        /// <summary>
        /// Initializes a new instance of the <see cref="VariableResult"/> class.
        /// </summary>
        /// <param name="name">Variable name.</param>
        /// <param name="type">Variable type.</param>
        /// <param name="value">Variable value.</param>
        public VariableResult(string name, DdeVariableType type, string value) { Name = name; VariableType = type; Value = value; }
        /// <summary>
        /// Variable Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Variable VariableType
        /// </summary>
        public DdeVariableType VariableType { get; set; }
        /// <summary>
        /// Variable value.
        /// <para>Write Operation: Stored new value to update.</para>
        /// <para>Read Operation: Return result value to client.</para>
        /// </summary>
        public string Value { get; set; }
    }

    /// <summary>
    /// Dde Application Server Class
    /// </summary>
    public class DdeAppServer : NDde.Server.DdeServer
    {
        #region [ Constants ]
        private const int AdviceLoopInterval = 100;
        private const int DDE_ERROR = -99; //Dummy Error Code
        #endregion

        private delegate void InternalFunctionCallback(DdeSystemFunction functionID, List<String> parameters);

        #region [ Callbacks ]
        private FunctionCallback OnFunctionCall;
        private VariableAccessCallback OnVariableRead;
        private VariableAccessCallback OnVariableWrite;
        private ShutdownRequestCallback OnShutDownRequest;
        #endregion

        #region [ Private Types ]
        private enum DdeSystemFunction
        {
            HideMainForm = 0,
            RestoreWindow,
            MinimizeWindow,
            BringToFront,
            SetWindowPosition
        }
        private struct DdeFunction
        {
            public int ID;
            public string Name;
            public string Description;
        }
        private class DdeVariable
        {
            public DdeVariable()
            {
                Type = DdeVariableType.String;
                Name = Value = "";
                ReadOnly = true;
            }
            public DdeVariableType Type;
            public string Name;
            public bool ReadOnly;
            public string Value;
        }
        #endregion

        #region [ Private Fields ]
        private Form _MainForm;
        private System.Timers.Timer _Timer;
        private static DdeAppServer _Server;
        private static string _ApplicationName;
        private int UniqueFuncID;
        private bool Enabled;   //true = Online; false = Offline

        private string DestApp;
        private string Keyword;
        private string DDECmd;

        List<DdeFunction> Functions;
        List<DdeVariable> Variables;
        List<string> ParamList;
        List<string> ResultBuffer;
        List<string> ClientList;
        #endregion

        #region [ Public Fields ]
        /// <summary> 
        /// Number of client connected with server. 
        /// </summary>
        public int ClientSize { get { return ClientList.Count; } }
        /// <summary>
        /// Return list of connected clients
        /// </summary>
        public IList<string> Clients
        {
            get
            {
                if(ClientList.Count == 0) return null;
                return ClientList;
            }
        }
        #endregion
        
        #region [ Constructor ]
        /// <summary>
        /// Singleton Constructor
        /// </summary>
        /// <param name="mainForm">Application Main Form pointer</param>
        /// <returns>singleton instance</returns>
        public static DdeAppServer SingleInstance(Form mainForm)
        {
            _ApplicationName = System.IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath);
            if(_Server == null) _Server = new DdeAppServer(mainForm, _ApplicationName);
            return _Server;
        }
        /// <summary>
        /// Protected Constructor. Called by Singleton Constructor
        /// </summary>
        /// <param name="mainForm">Application Main Form pointer</param>
        /// <param name="service">DdeApp Service name. Used Application name</param>
        protected DdeAppServer(Form mainForm, string service)
            : base(service)
        {
            ErrorMessage = new ErrorControl();
            _MainForm = (Form)mainForm;

            //Initialize Local Variables
            Functions = new List<DdeFunction>();
            Variables = new List<DdeVariable>();
            ParamList = new List<string>();
            ResultBuffer = new List<string>();
            ClientList = new List<string>();

            Enabled = false;
            UniqueFuncID = 10;

            //Create a timer that will be used to advise clients of new data.
            _Timer = new System.Timers.Timer();
            _Timer.Elapsed += this.OnTimerElapsed;
            _Timer.Interval = AdviceLoopInterval;
            _Timer.SynchronizingObject = this.Context;
            
            //Initialize DdeAppServer status
            Online();

            RegisterFunction("Help", "");
            RegisterFunction("HideMainForm", "");
            RegisterFunction("RestoreWindow", "");
            RegisterFunction("MinimizeWindow", "");
            RegisterFunction("BringToFront", "");
            RegisterFunction("SetWindowPosition", "<X> <Y>");

            RegisterVariable("FunctionList", DdeVariableType.String, true);
            RegisterVariable("VariableList", DdeVariableType.String, true);

        }
        #endregion

        #region [ Destructor ]
        /// <summary>
        /// Gets or sets a value indicating whether this instance is disposed.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is disposed; otherwise, <c>false</c>.
        /// </value>
        public bool IsDisposed { private set; get; }
        /// <summary>
        /// This contains the implementation to release all resources held by this instance.
        /// </summary>
        /// <param name="disposing">True if called by Dispose, false otherwise.</param>
        protected override void Dispose(bool disposing)
        {
            if(IsDisposed == true) return;
            if(disposing)
            {
                //Free managed resources
                if(IsRegistered == true) Unregister();
                Application.DoEvents();
                _Timer.Stop();
                _Timer.Dispose();
            }
            //Free unmanaged resources
            IsDisposed = true;
        }
        #endregion

        #region [ Error Handling ]
        private static ErrorControl ErrorMessage;
        private enum ErrorCode { BadFuncName, DupFuncName, BadVarName, DupVarName };
        private class ErrorControl : ErrorHandler
        {
            protected override string GetErrorMessage(object errorcode)
            {
                switch((ErrorCode)errorcode)
                {
                    case ErrorCode.BadFuncName: return "Unable to register function [ %1 ]. Function name must be single word!";
                    case ErrorCode.DupFuncName: return "Unable to register function [ %1 ]. Function previously registered!";
                    case ErrorCode.BadVarName: return "Unable to register variable [ %1 ]. Variable name must be single word!";
                    case ErrorCode.DupVarName: return "Unable to register variable [ %1 ]. Variable previously registered!";
                    default: return "Unknown error.";
                }
            }
        }
        #endregion
        
        #region [ Private Methods ]
        private int GetDdeFunctionID(string ddeFunction)
        {
            for(int x = 0; x < Functions.Count; x++)
            {
                if(string.Compare(Functions[x].Name, ddeFunction, DdeShared.CMP_IGNORE_CASE) == 0)
                    return Functions[x].ID;
            }
            return DDE_ERROR;
        }
        private static bool IsInternalFunction(string ddeFunction, ref DdeSystemFunction systemFunctionID)
        {
            try
            {
                systemFunctionID = (DdeSystemFunction)System.Enum.Parse(new DdeSystemFunction().GetType(), ddeFunction, true);
                return true;
            }
            catch(ArgumentException)
            {
                return false;
            }
        }
        private DdeVariable FindVariable(string variable)
        {
            for(int x = 0; x < Variables.Count; x++)
            {
                if(string.Compare(Variables[x].Name, variable, DdeShared.CMP_IGNORE_CASE) == 0)
                    return Variables[x];
            }
            return null;
        }
        private void VariableCheck(ref DdeVariable variable, string operation)
        {
            bool tVarValid = true;
            switch(variable.Type)
            {
                case DdeVariableType.Integer:
                    try { Convert.ToInt32(variable.Value); }
                    catch(InvalidCastException)
                    {
                        ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                            operation + " " + variable.Name + " : Invalid Integer Value!"));
                    }
                    break;

                case DdeVariableType.Double:
                    try { Convert.ToDouble(variable.Value); }
                    catch(InvalidCastException)
                    {
                        ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                            operation + " " + variable.Name + " : Invalid Double Value!"));
                    }
                    break;

                case DdeVariableType.String:
                    if(variable.Value.Contains(" ") == true)
                        variable.Value = "\"" + variable.Value + "\"";
                    break;
            }

            if(tVarValid == true)
            {
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Variable,
                    operation + " " + variable.Name + " OK " + variable.Value));
            }
        }
        private void ExecuteSystemCommand()
        {
            if(string.Compare(DDECmd, "Connect", DdeShared.CMP_IGNORE_CASE) == 0)
            {
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.System, "CONNECTION_OPEN " + Version()));
                ClientList.Add(DestApp); //Register DdeAppClient
                OnClientConnected(DestApp);
            }
            else if(string.Compare(DDECmd, "Disconnect", DdeShared.CMP_IGNORE_CASE) == 0)
            {
                //Unregister DdeAppClient
                if(ClientList.Contains(DestApp))
                    ClientList.Remove(DestApp);
                OnClientDisconnected(DestApp);
            }
            else if(string.Compare(DDECmd, "Shutdown", DdeShared.CMP_IGNORE_CASE) == 0)
            {
                if(OnShutDownRequest != null) OnShutDownRequest();
                else ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp,
                    DdeCommandType.Error, "Shutdown Failed! Function Not Implemented!"));
            }
        }
        private void ExecuteDdeFunction()
        {
            string tFuncReturn = "";
            DdeSystemFunction sysFuncID = DdeSystemFunction.BringToFront;

            //Check DdeAppClient Connection status
            if(ClientList.Contains(DestApp) == false)
            {
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                    "Server Not Connected!"));
                return;
            }

            //======================= INTERNAL REGISTERED FUNCTION =======================
            #region Internal DdeFunction
            if(string.Compare(DDECmd, "Help", DdeShared.CMP_IGNORE_CASE) == 0)
            {
                DdeHelp(DestApp);
                tFuncReturn = DDECmd + " 0 " + "OK";
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Function, tFuncReturn));
            }
            else if(IsInternalFunction(DDECmd, ref sysFuncID) == true)
            {
                try
                {
                    _MainForm.BeginInvoke(new InternalFunctionCallback(ExecuteInternalFunction), new object[] { sysFuncID, ParamList });
                    tFuncReturn = DDECmd + " 0 " + "OK";
                    ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Function, tFuncReturn));
                }
                catch(Exception ex)
                {
                    ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                        "Exception raised from InternalFunction() : " + ex.Message));
                }
            }
            #endregion
            //============================================================================

            else if(GetDdeFunctionID(DDECmd) > 0)
            {
                //USER SPECIFIC FUNCTION
                if(OnFunctionCall != null)
                {
                    //Remove Header. Only forward ddeFunction parameter.
                    ParamList.RemoveRange(0, DdeShared.ParamPos);

                    //DdeFunction Execution
                    try
                    {
                        FunctionResult result = new FunctionResult();
                        result.Function = DDECmd;
                        result.SetFunctionParameters(ParamList);
                        result.Client = DestApp;
                        OnFunctionCall(result);

                        tFuncReturn = DDECmd + " " + result.Status + " \"" + result.Message + "\"";
                        ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Function, tFuncReturn));
                    }
                    catch(Exception ex)
                    {
                        //Handle exception from server's ddeFunction
                        tFuncReturn = DDECmd + " " + "-1001" + " \"" + ex.ToString() + "\"";
                        ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error, tFuncReturn));
                    }
                }
                else
                {
                    //Raised Error when OnFunctionCall not implemented
                    ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                        "OnFunctionCall() Event not implemented! Function not executed!"));
                }
            }
            else
            {
                //Raised Error for unhandled DdeFunction
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                    "Unable to proceed! Function not registered : [" + DDECmd + "]"));
            }
        }
        private void ExecuteVariableOperation()
        {
            //Check DdeAppClient Connection status
            if(ClientList.Contains(DestApp) == false)
            {
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                    "Server Not Connected!"));
                return;
            }

            //Variables name check
            if(ParamList.Count < 5)
            {
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                    "Missing Variable Name!"));
                return;
            }

            //Verify Variables
            DdeVariable ptrVar = FindVariable(ParamList[DdeShared.ParamPos]);
            if(ptrVar == null)
            {
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                    "Variable Unregistered : " + ParamList[DdeShared.ParamPos]));
            }
            //READ VARIABLE
            else if(string.Compare(DDECmd, "Read", DdeShared.CMP_IGNORE_CASE) == 0)
            {
                //=============== INTERNAL REGISTERED VARIABLES ==============
                if(string.Compare(ptrVar.Name, "FunctionList", DdeShared.CMP_IGNORE_CASE) == 0)
                {
                    string funcList = "";
                    foreach(DdeFunction pFunc in Functions) funcList += pFunc.Name + " ";
                    ptrVar.Value = DDECmd + " " + ptrVar.Name + " OK " + funcList;
                    ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Variable, ptrVar.Value));
                }
                else if(string.Compare(ptrVar.Name, "VariableList", DdeShared.CMP_IGNORE_CASE) == 0)
                {
                    string varList = "";
                    foreach(DdeVariable pVar in Variables) varList += pVar.Name + " ";
                    ptrVar.Value = DDECmd + " " + ptrVar.Name + " OK " + varList;
                    ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Variable, ptrVar.Value));
                }
                //============================================================

                else if(OnVariableRead != null)
                {
                    //**** User Callback ****
                    VariableResult result = new VariableResult(ptrVar.Name, ptrVar.Type);
                    OnVariableRead(result);
                    ptrVar.Value = result.Value;
                    VariableCheck(ref ptrVar, "Read"); //Check returned value
                }
                else
                {
                    ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                        "OnVariableRead() Event not implemented!"));
                }
            }
            else if(string.Compare(DDECmd, "Write", DdeShared.CMP_IGNORE_CASE) == 0)
            {
                if(OnVariableWrite != null)
                {
                    if(ptrVar.ReadOnly == true)
                    {
                        ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                            ptrVar.Name + " is write protected!"));
                    }
                    else
                    {
                        VariableResult result = new VariableResult(ptrVar.Name, ptrVar.Type, ptrVar.Value);
                        OnVariableWrite(result);
                        VariableCheck(ref ptrVar, "Write"); //Check returned value
                    }
                }
                else
                {
                    ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                        "OnVariableWrite() Event not implemented!"));
                }
            }
            else //Keyworn unknown (DDECmd)
            {
                //Raised Error for unhandled DdeFunction
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                        "Unknown Variable Access Keyword : " + DDECmd));
            }
        }
        private void ExecuteInternalFunction(DdeSystemFunction functionID, List<String> parameters)
        {
            try
            {
                switch(functionID)
                {
                    case DdeSystemFunction.HideMainForm:
                        _MainForm.Visible = false;
                        break;

                    case DdeSystemFunction.RestoreWindow:
                        _MainForm.WindowState = FormWindowState.Normal;
                        _MainForm.Visible = true;
                        break;

                    case DdeSystemFunction.MinimizeWindow:
                        _MainForm.WindowState = FormWindowState.Minimized;
                        _MainForm.Visible = true;
                        break;

                    case DdeSystemFunction.BringToFront:
                        //Work Around : BringToFront() not work properly.
                        _MainForm.WindowState = FormWindowState.Normal;
                        _MainForm.Visible = true;
                        _MainForm.TopMost = true;
                        _MainForm.TopMost = false;
                        break;

                    case DdeSystemFunction.SetWindowPosition:
                        parameters.RemoveRange(0, DdeShared.ParamPos - 1);
                        _MainForm.Visible = true;
                        if(parameters.Count < 2)
                        {
                            _MainForm.Top = 0;
                            _MainForm.Left = 0;
                        }

                        try { _MainForm.Left = Convert.ToInt32(parameters[1]); }
                        catch(FormatException) { _MainForm.Left = 0; }
                        catch(OverflowException) { _MainForm.Left = 0; }

                        try { _MainForm.Top = Convert.ToInt32(parameters[2]); }
                        catch(FormatException) { _MainForm.Top = 0; }
                        catch(OverflowException) { _MainForm.Top = 0; }
                        break;
                }
            }
            catch(Exception ex)
            {
                //Ignore any exception in internal ddeFunction
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error,
                    "Exception Raised from Internal Function " + Enum.GetName(typeof(DdeSystemFunction), functionID) + " :\n" + 
                    ex.Message));
                return;
            }
        }
        private void DdeHelp(string destination)
        {
            DestApp = destination;
            AddResultInfo("<<<< DDE APPLICATION (" + _ApplicationName + ") Version : " + Version() + " >>>>");
            AddResultInfo("Usage: <Source> <Dest> <Commands>");
            AddResultInfo("  ");
            AddResultInfo("<Source> : Sender Application EXE Name");
            AddResultInfo("<Dest>   : Receiver Application EXE Name");
            AddResultInfo("<Cmds>   : [DDE.Function, DDE.Variable]");
            AddResultInfo("  ");
            AddResultInfo("#### Function Call ####");
            AddResultInfo("  - SEND    : DDE.Function <FunctionName> [Param1] ... [ParamN]");
            AddResultInfo("  - RECEIVE : DDE.Function <FunctionName> <Status> [Return Message]");
            AddResultInfo("  ");
            AddResultInfo("#### Variable Access ####");
            AddResultInfo("  - SEND    : DDE.Variable <Read/Write> <VariableName> [Value]");
            AddResultInfo("  - RECEIVE : DDE.Variable Read <VariableName> <Status> <Value>");
            AddResultInfo("  -           DDE.Variable Write <VariableName> <Status> <Value>");
            AddResultInfo("  ");
            AddResultInfo("#### FUNCTIONS ####");
            for(int x = 0; x < Functions.Count; x++)
                AddResultInfo("\t" + Functions[x].Name + "\t" + Functions[x].Description);

            AddResultInfo("   ");
            AddResultInfo("#### VARIABLES ####");
            if(Variables.Count == 0) AddResultInfo("\t<NONE>");
            for(int x = 0; x < Variables.Count; x++)
            {
                string tAttr, tType = "";
                switch(Variables[x].Type)
                {
                    case DdeVariableType.Integer: tType = "Int"; break;
                    case DdeVariableType.Double: tType = "Double"; break;
                    case DdeVariableType.String: tType = "AnsiString"; break;
                }

                if(Variables[x].ReadOnly == true) tAttr = "R"; else tAttr = "RW";
                AddResultInfo("\t" + Variables[x].Name + "\t" + tType + " " + tAttr);
            }
            AddResultInfo("   ");
            AddResultInfo("<<<< END >>>>");

        }
        private void AddResultInfo(string message) { ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Info, message)); }
        private void OnTimerElapsed(object sender, ElapsedEventArgs args)
        {
            // Advise all topic name and item name pairs.
            Advise("DDEServer", "*");
        }
        #endregion

        #region [ Public Methods ]
        /// <summary>
        /// Assign callback function to OnFunctionCall event.
        /// </summary>
        /// <param name="callback">callback function</param>
        public void SetFunctionCallback(FunctionCallback callback) { OnFunctionCall = callback; }
        /// <summary>
        /// Assign callback function to OnVariableRead event.
        /// </summary>
        /// <param name="callback">callback function</param>
        public void SetVariableReadCallback(VariableAccessCallback callback) { OnVariableRead = callback; }
        /// <summary>
        /// Assign callback function to OnVariableWrite event.
        /// </summary>
        /// <param name="callback">callback function</param>
        public void SetVariableWriteCallback(VariableAccessCallback callback) { OnVariableWrite = callback; }
        /// <summary>
        /// Assign callback function to OnVariableRead event.
        /// </summary>
        /// <param name="callback">callback function</param>
        public void SetShutdownRequestCallback(ShutdownRequestCallback callback) { OnShutDownRequest = callback; }
        /// <summary>
        /// Get DdeApp DdeAppServer Assembly Version
        /// </summary>
        /// <returns>Version string</returns>
        public string Version() { return this.GetType().Assembly.GetName().Version.ToString(); }
        /// <summary>
        /// Set DdeApp DdeAppServer Online (Enable DdeApp Communication)
        /// </summary>
        public void Online()
        {
            if(IsRegistered == false) Register();
            Enabled = true;
            ResultBuffer.Clear();
            ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, "_SYS_", DdeCommandType.System, "SERVER_ONLINE"));
        }
        /// <summary>
        /// Set DdeApp DdeAppServer Offline (Disable DdeApp Communication)
        /// </summary>
        public void Offline()
        {
            Enabled = false;
            ClientList.Clear();
            ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, "_SYS_", DdeCommandType.System, "SERVER_OFFLINE"));
            if(IsRegistered == true) Unregister();
        }
        /// <summary>
        /// Register user ddeFunction to be called from DdeAppClient.
        /// </summary>
        /// <param name="name">DdeFunction name</param>
        /// <param name="description">DdeFunction description</param>
        /// <exception cref="ArgumentException">Invalid name, duplicate name</exception>
        public void RegisterFunction(string name, string description)
        {
            if(name.Contains(" ") == true) throw new ArgumentException(ErrorMessage.Get(ErrorCode.BadFuncName, name));

            //Validate name is unique
            foreach(DdeFunction pFunc in Functions)
            {
                if(string.Compare(pFunc.Name, name, DdeShared.CMP_IGNORE_CASE) == 0)
                    throw new ArgumentException(ErrorMessage.Get(ErrorCode.DupFuncName, name));
            }

            DdeFunction nFunc = new DdeFunction();
            nFunc.Name = name;
            nFunc.ID = UniqueFuncID++;
            nFunc.Description = description;
            Functions.Add(nFunc);
        }
        /// <summary>
        /// Register variable to be access from client
        /// </summary>
        /// <param name="name">Variables name</param>
        /// <param name="variableType">Dde variable type defined in <seealso cref="DdeVariableType"/>.</param>
        /// <param name="readOnly">true = Read only, false = Read and Write</param>
        /// <exception cref="ArgumentException">Invalid name, duplicate name</exception>
        public void RegisterVariable(string name, DdeVariableType variableType, bool readOnly)
        {
            if(name.Contains(" ") == true) throw new ArgumentException(ErrorMessage.Get(ErrorCode.BadVarName, name));

            //Validate name is unique
            for(int x = 0; x < Variables.Count; x++)
            {
                if(string.Compare(Variables[x].Name, name) == 0)
                    throw new ArgumentException(ErrorMessage.Get(ErrorCode.DupVarName, name));
            }

            DdeVariable Var = new DdeVariable();
            Var.Name = name;
            Var.ReadOnly = readOnly;
            Var.Type = variableType;
            Var.Value = "";
            Variables.Add(Var);
        }
        /// <summary>
        /// Send Info messages to DdeAppClient
        /// </summary>
        /// <param name="text">message string</param>
        public void SendDebugMessage(string text)
        {
            ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, "_SYS_", DdeCommandType.Info, text));
        }
        /// <summary>
        /// (INTERNAL USE) Register DdeApp DdeAppServer.
        /// Do not call directly.
        /// </summary>
        public override void Register()
        {
            base.Register();
            _Timer.Start();
        }
        /// <summary>
        /// (INTERNAL USE) Unregister DdeApp DdeAppServer.
        /// Do not call directly.
        /// </summary>
        public override void Unregister()
        {
            _Timer.Stop();
            base.Unregister();
        }
        #endregion

        #region [ Events Handler ]
        /// <summary>
        /// Occus when client is connected to server.
        /// </summary>
        public event EventHandler<DdeAppEventArgs> ClientConnected;
        /// <summary>
        /// Occurs when client is disconnected from server.
        /// </summary>
        public event EventHandler<DdeAppEventArgs> ClientDisconnected;
        private void HandleDdeAppEvent(EventHandler<DdeAppEventArgs> eventHandler, DdeAppEventArgs e)
        {
            EventHandler<DdeAppEventArgs> handle = eventHandler;
            if(handle != null) handle(this, e);
        }
        private void OnClientConnected(string source) { HandleDdeAppEvent(ClientConnected, new DdeAppEventArgs(source)); }
        private void OnClientDisconnected(string source) { HandleDdeAppEvent(ClientDisconnected, new DdeAppEventArgs(source)); }

        /// <summary>
        /// Occurs when command / result is about to send to client.
        /// </summary>
        public event EventHandler<DdeAppCommandEventArgs> CommandSending;
        /// <summary>
        /// Occurs when command is receieved froms server.
        /// </summary>
        public event EventHandler<DdeAppCommandEventArgs> CommandReceived;
        /// <summary>
        /// Occurs when debug message is received from client.
        /// </summary>
        public event EventHandler<DdeAppCommandEventArgs> DebugMessageReceived;
        private void HandleDdeAppCommandEventArgs(EventHandler<DdeAppCommandEventArgs> eventHandler, DdeAppCommandEventArgs e)
        {
            EventHandler<DdeAppCommandEventArgs> handle = eventHandler;
            if(handle != null) handle(this, e);
        }
        private void OnCommandSending(string source, string text) { HandleDdeAppCommandEventArgs(CommandSending, new DdeAppCommandEventArgs(source, text)); }
        private void OnCommandReceived(string source, string text) { HandleDdeAppCommandEventArgs(CommandReceived, new DdeAppCommandEventArgs(source, text)); }
        private void OnDebugMessageReceived(string source, string text) { HandleDdeAppCommandEventArgs(DebugMessageReceived, new DdeAppCommandEventArgs(source, text)); }
        #endregion

        #region [ DdeServer Functions ]
        /// <summary>
        /// (INTERNAL USE) Event fired when DdeApp link between server and client is established
        /// </summary>
        /// <param name="conversation">DdeApp DdeAppClient</param>
        protected override void OnAfterConnect(DdeConversation conversation)
        {
            base.OnAfterConnect(conversation);
        }
        /// <summary>
        /// (INTERNAL USE) Event fired when DdeApp link between server and client is closed
        /// </summary>
        /// <param name="conversation">DdeApp DdeAppClient</param>
        protected override void OnDisconnect(DdeConversation conversation)
        {
            base.OnDisconnect(conversation);
        }
        /// <summary>
        /// (INTERNAL USED) Required to sustain DdeApp communication.
        /// </summary>
        protected override bool OnStartAdvise(DdeConversation conversation, string item, int format)
        {
            return format == 1;
        }
        /// <summary>
        /// (INTERNAL USE) Event respond to NDDE.DdeAppClient.BeginExecute().
        /// DdeApp DdeFunction are processed in this ddeFunction.
        /// </summary>
        /// <param name="conversation">DdeAppClient who execute the ddeFunction</param>
        /// <param name="command">Text sent by client</param>
        /// <returns>Execution Result</returns>
        protected override ExecuteResult OnExecute(DdeConversation conversation, string command)
        {
            if(string.IsNullOrEmpty(command) == true) return ExecuteResult.Processed;
            OnCommandReceived(_ApplicationName, command);
            command = command.Trim();

            //Decode command
            ParamList.Clear();
            ParamList.AddRange(command.Split(' '));
            ResultBuffer.Clear();

            //Special access for non standard DdeApp protocol
            if(string.Compare(ParamList[0], "Help", DdeShared.CMP_IGNORE_CASE) == 0)
            {
                //command = "_SYS_ _SYS_ DdeApp.DdeFunction Help";
                //ParamList.AddRange(command.Split(' '));
                DdeHelp("_SYS_");
                string tFuncReturn = "Help 0 OK";
                ResultBuffer.Add(DdeShared.FormatDdeMessage("_SYS_", "_SYS_", DdeCommandType.Function, tFuncReturn));
            }

            //Check for minimum param size
            if(ParamList.Count < 4) return ExecuteResult.Processed; //Drop

            //message Protocol
            DestApp = ParamList[0];
            Keyword = ParamList[2];
            DDECmd = ParamList[3];

            //Check DdeAppServer status
            if(Enabled == false)
                ResultBuffer.Add(DdeShared.FormatDdeMessage(_ApplicationName, DestApp, DdeCommandType.Error, "Server Offlined."));
            
            //Internal Process
            switch(DdeShared.Keywords[Keyword])
            {
                case DdeCommandType.System: ExecuteSystemCommand(); break;
                case DdeCommandType.Function: ExecuteDdeFunction(); break;
                case DdeCommandType.Variable: ExecuteVariableOperation(); break;
                case DdeCommandType.Info:
                    if(DebugMessageReceived != null)
                    {
                        ParamList.RemoveRange(0, DdeShared.ParamPos - 1);
                        OnDebugMessageReceived(DestApp, ParamList.ToString());
                    }
                    break;
            }

            //Finalization
            return ExecuteResult.Processed;
        }
        /// <summary>
        /// (INTERNAL USE) Event fired at the end of DdeApp ddeFunction execution when ExecuteResult.Processed is set.
        /// Result are returned to client from this ddeFunction
        /// </summary>
        /// <param name="conversation">DdeAppClient who execute this ddeFunction (NOT USED)</param>
        /// <param name="item">incoming message</param>
        /// <param name="format">Only process if format == 1</param>
        /// <returns>Ignored = RequestResult.NotProcessed / Processed = RequestResult(ResultBytes)</returns>
        protected override RequestResult OnRequest(DdeConversation conversation, string item, int format)
        {
            byte[] ResultBytes;
            string ResultStr;

            if(format != 1) return RequestResult.NotProcessed;
            if(ResultBuffer.Count != 0)
            {
                ResultStr = "";
                foreach(string tLine in ResultBuffer) ResultStr += tLine + "\n";
                ResultBytes = System.Text.Encoding.ASCII.GetBytes(ResultStr + "\0");
                OnCommandSending(_ApplicationName, ResultStr);
                ResultBuffer.Clear();
                return new RequestResult(ResultBytes);
            }
            return RequestResult.NotProcessed;
        }
        #endregion
    }

    /// <summary>
    /// Dde Application Client Class
    /// </summary>
    public class DdeAppClient: IDisposable
    {
        //UNDONE: [BUG] Exception thrown in command ShutdownServer

        #region [ Constants ]
        private const int ADVISE_TIMEOUT = 10000;
        #endregion

        #region [ Private Types ]
        private class DdeClientItem
        {
            /// <summary>
            /// DdeAppServer's DdeApp version
            /// </summary>
            public string Version;
            /// <summary>
            /// NDDE DdeAppClient object
            /// </summary>
            public DdeClient Client;
            /// <summary>
            /// DdeAppServer's name (Full Path)
            /// </summary>
            public string AppName;
            /// <summary>
            /// TRUE = auto launch server application on connect if not started
            /// </summary>
            public bool AutoLaunch;
            /// <summary>
            /// Store DdeApp link status.
            /// (Different from NDDE link status)
            /// </summary>
            public bool Connected;
        }
        #endregion
        
        #region [ Private Fields ]
        private Dictionary<string, DdeClientItem> Items;	//ClientConnected client list
        private static List<string> ParamList;
        private string _ApplicationName;

        //Execution Wait Control
        private bool _Waiting;
        private bool _WaitTimeout;
        private int _WaitStatus;
        private string _WaitClient;
        private string _WaitMessage;
        private System.Timers.Timer DdeTimer;
        #endregion

        #region [ Public Fields ]
        /// <summary>
        /// Dde operation watch dog timer.
        /// </summary>
        public double Timeout
        {
            get { return DdeTimer.Interval; }
            set { DdeTimer.Interval = value; }
        }
        /// <summary>
        /// Get list of current registered servers.
        /// </summary>
        public ICollection<string> GetServerList
        {
            get
            {
                if(Items.Count == 0) return null;
                return Items.Keys;
            }
        }
        #endregion

        #region [ Constructor ]
        /// <summary>
        /// Constructor
        /// </summary>
        public DdeAppClient()
        {
            //Initialize Local Variables
            _Waiting = false;
            Items = new Dictionary<string, DdeClientItem>();
            ParamList = new List<string>();
            ErrorMessage = new ErrorControl();
          
            DdeTimer = new System.Timers.Timer(1000);
            DdeTimer.Enabled = false;
            DdeTimer.Elapsed += OnTimeout;

            //Register DdeAppClient's Application name
            _ApplicationName = System.IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath);
        }
        #endregion

        #region [ Destructor ]
        /// <summary>
        /// Check if instance was disposed
        /// </summary>
        public bool IsDisposed { private set; get; }
        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if(IsDisposed == true) return;
            if(disposing)
            {
                //Free managed resource
                foreach(KeyValuePair<string, DdeClientItem> ptrItem in Items)
                {
                    ptrItem.Value.Client.Dispose();   
                }
                DdeTimer.Stop();
                DdeTimer.Dispose();
                Items.Clear();
            }
            //Free unmanaged resources
            IsDisposed = true;
        }
        #endregion
      

        #region [ Error Handling ]
        private ErrorControl ErrorMessage;
        private enum ErrorCode
        {
            BadServer, DupServer, InvServer,
            LinkErr, ServerErr, FuncErr, LinkClosed, Busy, FuncTimeout,
        };
        private class ErrorControl : ErrorHandler
        {
            protected override string GetErrorMessage(object errorCode)
            {
                switch((ErrorCode)errorCode)
                {
                    case ErrorCode.BadServer: return "Unable to create server with [ %1 ].\nInvalid Application Extension [ %2 ]! Only EXE is allowed!";
                    case ErrorCode.DupServer: return "Unable to create server with [ %1 ].\nCannot create multiple DDE server with same name [%2]!";

                    case ErrorCode.InvServer: return "Invalid server [ %1 ]!";
                    case ErrorCode.LinkErr: return "Unable to establish link with Server [ %1 ]";
                    case ErrorCode.ServerErr: return "Unable to connect to Server [ %1 ], probably NON DdeApp Type Server";
                    case ErrorCode.FuncErr: return "Unable to execute DDE Function [ %1 ]!";
                    case ErrorCode.LinkClosed: return "Unable to execute command [ %1 ], server not connected!";

                    case ErrorCode.Busy: return "Unable to process multiple function call, DdeApp Client is busy!";
                    case ErrorCode.FuncTimeout: return "DDE Function Call Timeout!";

                    default: return "Unknown Error!";
                }
            }
        }
        #endregion

        #region [ Private Methods ]
        private void VerifyService(string serverName)
        {
            if((serverName.Length == 0) || (Items.ContainsKey(serverName) == false))
                throw new ArgumentException(ErrorMessage.Get(ErrorCode.InvServer, serverName));
        }
        private void ExecuteDdeFunction(DdeClientItem client, DdeCommandType commandType, string command)
        {
            client.Client.BeginExecute(DdeShared.FormatDdeMessage(_ApplicationName, client.Client.Service, commandType, command),
                OnExecuteComplete, client.Client);
            client.Client.BeginRequest("ServerData", 1, OnRequesetComplete, client.Client);
        }
        private void ExecuteDdeFunctionNoReply(DdeClientItem client, DdeCommandType commandType, string command)
        {
            client.Client.BeginExecute(DdeShared.FormatDdeMessage(_ApplicationName, client.Client.Service, commandType, command),
                OnExecuteComplete, client.Client);
        }
        private void WaitForEvent(string client)
        {
            _WaitClient = client;
            _Waiting = true;
            _WaitTimeout = false;
            _WaitStatus = 0;

            //Run Wait loop until signaled by WaitComplete() / Timeout
            DdeTimer.Enabled = true;
            do { Application.DoEvents(); }
            while((_Waiting == true) && (_WaitTimeout == false));
            DdeTimer.Enabled = false;

            if(_WaitTimeout) throw new DdeAppFuncException(ErrorMessage.Get(ErrorCode.FuncTimeout));
        }
        private bool WaitComplete(string client, int status, string message)
        {
            if(_Waiting == false) return false;
            if(_WaitClient == client)
            {
                _Waiting = false;
                _WaitStatus = status;
                _WaitMessage = message;
                return true;
            }
            return false;
        }
        private void OnTimeout(object sender, ElapsedEventArgs e)
        {
            DdeTimer.Enabled = false;
            if(_Waiting == true)
            {
                _Waiting = false;
                _WaitTimeout = true;
            }
        }
        #endregion

        #region [ Public Methods ]
        /// <summary>
        /// Get DdeApp DdeAppServer Assembly Version
        /// </summary>
        /// <returns>Verion string</returns>
        public string Version() { return this.GetType().Assembly.GetName().Version.ToString(); }
        /// <summary>
        /// Execute DdeApp DdeFunction on DdeAppServer Application.
        /// DdeFunction return immediately after command is send to server.
        /// </summary>
        /// <param name="serverName">receiver server's name</param>
        /// <param name="command">DdeFunction with optional arguments</param>
        /// <example>FunctionA Param0 Param1 "Multi Word Param 2"</example>
        /// <exception cref="DdeAppFuncException">DdeApp is still busy.</exception>
        /// <exception cref="DdeAppLinkException">DdeApp server not connected</exception>
        public void FunctionCall(string serverName, string command)
        {
            if(_Waiting == true) throw new DdeAppFuncException(ErrorMessage.Get(ErrorCode.Busy));
            VerifyService(serverName);

            DdeClientItem pDDEItem = Items[serverName];
            if(pDDEItem.Client.IsConnected == false)
                throw new DdeAppLinkException(ErrorMessage.Get(ErrorCode.LinkClosed, command));
            ExecuteDdeFunction(pDDEItem, DdeCommandType.Function, command);
        }
        /// <summary>
        /// Execute DdeApp DdeFunction on DdeAppServer Application.
        /// Wait until ddeFunction complete executed / timeout reached.
        /// Wait duration defined by variable : Timeouot.
        /// </summary>
        /// <param name="serverName">receiver server's name</param>
        /// <param name="command">DdeFunction with optional arguments</param>
        /// <param name="result">Dde function result returned from server.</param>
        /// <example>FunctionA Param0 Param1 "Multi Word Param 2"</example>
        public void FunctionCall(string serverName, string command, FunctionResult result)
        {
            //return ddeFunction status
            FunctionCall(serverName, command);
            WaitForEvent(serverName);
            result.Status = _WaitStatus;
            result.Message = _WaitMessage;
        }
        /// <summary>
        /// Add / Register DdeApp DdeAppServer Application to list
        /// </summary>
        /// <param name="applicationName">DdeAppServer Application (Full Path)</param>
        /// <param name="autoLaunch">When set to TRUE, automatically launch server if not started.</param>
        /// <returns>serverName for newly added Dde Application. Returned serverName is used for subsequent function</returns>
        /// <exception cref="ArgumentException">Invalid Application name / duplicate server</exception>
        public string Add(string applicationName, bool autoLaunch)
        {
            string serverName = "";

            //Verify Extension if Included. Only EXE is allowed
            string tExt = System.IO.Path.GetExtension(applicationName);
            if((tExt.Length != 0) && (string.Compare(tExt, "exe", true) == 0))
                throw new ArgumentException(ErrorMessage.Get(ErrorCode.BadServer, new string[] { applicationName, tExt }));

            //Extract service name from full _ApplicationName path (without extension)
            serverName = System.IO.Path.GetFileNameWithoutExtension(applicationName);

            //Validate Unique Service name
            if(Items.ContainsKey(serverName))
                throw new ArgumentException(ErrorMessage.Get(ErrorCode.DupServer, new string[] { applicationName, serverName }));

            //Create DdeApp DdeAppClient Entry (Unique Service name)
            DdeClientItem pDDEItem = new DdeClientItem();
            pDDEItem.AppName = applicationName;
            pDDEItem.AutoLaunch = autoLaunch;

            pDDEItem.Client = new DdeClient(serverName, "DDEServer");
            pDDEItem.Client.Disconnected += OnLinkClosed; //LinkClosed

            Items.Add(serverName, pDDEItem);

            //Implement Auto Lauch
            if(pDDEItem.AutoLaunch) Connect(serverName);
            return serverName;
        }
        /// <summary>
        /// Remove and disconnect all registered DdeApp Application DdeAppServer
        /// </summary>
        public void DeleteAll()
        {
            foreach(KeyValuePair<string, DdeClientItem> ptrItem in Items)
            {
                ptrItem.Value.Client.Disconnected -= OnLinkClosed;
                if(ptrItem.Value.Client.IsConnected == true) ptrItem.Value.Client.Disconnect();
            }
            Items.Clear();
        }
        /// <summary>
        /// Manually connect to DdeApp server
        /// </summary>
        /// <param name="serverName">Target server application</param>
        /// <exception cref="DdeAppLinkException">Failed to establish connection with server.</exception>
        public void Connect(string serverName)
        {
            //Add Connection Timeout and Connection try
            VerifyService(serverName);

            DdeClientItem pDDEItem = Items[serverName];
            bool FlgFirstTry = true;
            while(true)
            {
                try
                {
                    if(pDDEItem.Client.IsConnected == false) pDDEItem.Client.Connect();

                    //DdeAppServer ClientConnected
                    ExecuteDdeFunction(pDDEItem, DdeCommandType.System, "Connect");
                    return;
                }
                catch(Exception ex)
                {
                    if(FlgFirstTry)
                    {
                        FlgFirstTry = false;
                        System.Diagnostics.Process.Start(pDDEItem.AppName);
                        System.Threading.Thread.Sleep(2000);
                    }
                    else
                    {
                        throw new DdeAppLinkException(ErrorMessage.Get(ErrorCode.LinkErr, serverName), ex);
                    }
                }
            }
        }
        /// <summary>
        /// Disconnect a DdeApp server. DdeAppServer Application remain active.
        /// </summary>
        /// <param name="serverName">Target server application</param>
        public void Disconnect(string serverName)
        {
            VerifyService(serverName);
            DdeClientItem ptrItem = Items[serverName];
            if(ptrItem.Connected == false) return;

            ExecuteDdeFunctionNoReply(ptrItem, DdeCommandType.System, "Disconnect");
            if(ptrItem.Connected == true)
            {
                ptrItem.Connected = false;
                ptrItem.Client.Disconnect();
            }
        }
        /// <summary>
        /// Shut down DdeAppServer Application
        /// </summary>
        /// <param name="serverName">Target server application</param>
        /// <remarks>DdeAppServer application need to implement OnClientShutdownQuery event.</remarks>
        public void ShutdownServer(string serverName)
        {
            VerifyService(serverName);
            DdeClientItem ptrItem = Items[serverName];
            ExecuteDdeFunction(ptrItem, DdeCommandType.System, "ShutDown");
        }
        /// <summary>
        /// Shut down all server application
        /// </summary>
        /// <remarks>DdeAppServer application need to implement OnClientShutdownQuery event.</remarks>
        public int ShutdownAllServer()
        {
            foreach(KeyValuePair<string, DdeClientItem> ptrItem in Items)
            {
                if(ptrItem.Value.Connected == true)
                    ShutdownServer(ptrItem.Key);
            }
            return 0;
        }
        /// <summary>
        /// Check connection status of specified server.
        /// </summary>
        /// <param name="serverName">Target server application</param>
        /// <returns>TRUE = connected</returns>
        public bool GetConnectStatus(string serverName)
        {
            VerifyService(serverName);
            return Items[serverName].Connected;
        }
        /// <summary>
        /// Query Version from DdeApp DdeAppServer Application.
        /// </summary>
        /// <param name="serverName">Target server application</param>
        /// <returns>Version string</returns>
        public string GetVersion(string serverName)
        {
            VerifyService(serverName);
            return Items[serverName].Version;
        }
        
        /// <summary>
        /// Get server application's source path
        /// </summary>
        /// <param name="serverName">Target server application</param>
        /// <returns>return Application's source path.</returns>
        public string GetApplicationLocation(string serverName)
        {
            VerifyService(serverName);
            return Items[serverName].AppName;
        }
        /// <summary>
        /// Read a variable from server application
        /// </summary>
        /// <param name="serverName">Target server application</param>
        /// <param name="variable">name of variable to read</param>
        /// <param name="result">Variable read result</param>
        /// <exception cref="DdeAppFuncException">DdeApp </exception>
        public void VariableRead(string serverName, string variable, VariableResult result)
        {
            if(_Waiting == true) throw new DdeAppFuncException(ErrorMessage.Get(ErrorCode.Busy));

            VerifyService(serverName);
            DdeClientItem pDDEItem = Items[serverName];

            string tCommand = "Read " + variable +" " + result.Value;
            ExecuteDdeFunction(pDDEItem, DdeCommandType.Variable, tCommand);
            WaitForEvent(serverName);
            result.Value = _WaitMessage;
        }
        /// <summary>
        /// Write new value to a registered variable in server application
        /// </summary>
        /// <param name="serverName">Target server application</param>
        /// <param name="variable">variable to write</param>
        /// <param name="value">new value</param>
        /// <remarks>Variables must be write enable</remarks>
        /// <exception cref="DdeAppFuncException">DdeApp is still busy.</exception>
        public void VariableWrite(string serverName, string variable, string value)
        {
            if(_Waiting == true) throw new DdeAppFuncException(ErrorMessage.Get(ErrorCode.Busy));

            VerifyService(serverName);
            DdeClientItem pDDEItem = Items[serverName];

            string tCommand = "Write " + variable + " " + value;
            ExecuteDdeFunction(pDDEItem, DdeCommandType.Variable, tCommand);
            WaitForEvent(serverName);
        }
        #endregion

        #region [ Events Handler ]
        /// <summary>
        /// Occurs when server had been connected.
        /// </summary>
        public event EventHandler<DdeAppEventArgs> ServerConnected;
        /// <summary>
        /// Occurs when server had been disconnected.
        /// </summary>
        public event EventHandler<DdeAppEventArgs> ServerDisconnected;
        /// <summary>
        /// Occurs when server is resume online from offline.
        /// </summary>
        public event EventHandler<DdeAppEventArgs> ServerOnline;
        private void HandleDdeAppEvent(EventHandler<DdeAppEventArgs> eventHandler, DdeAppEventArgs e)
        {
            EventHandler<DdeAppEventArgs> handle = eventHandler;
            if(handle != null) handle(this, e);
        }
        private void OnConnected(string source) { HandleDdeAppEvent(ServerConnected, new DdeAppEventArgs(source)); }
        private void OnDisconnected(string source){ HandleDdeAppEvent(ServerDisconnected, new DdeAppEventArgs(source)); }
        private void OnServerOnline(string source) { HandleDdeAppEvent(ServerOnline, new DdeAppEventArgs(source)); }

        /// <summary>
        /// Occurs when debug message is recieved from Server.
        /// </summary>
        public event EventHandler<DdeAppCommandEventArgs> DebugMessageReceived;
        /// <summary>
        /// Occurs when command's respond is received.
        /// </summary>
        public event EventHandler<DdeAppCommandEventArgs> RespondReceived;
        private void HandleDdeAppCommandEventArgs(EventHandler<DdeAppCommandEventArgs> eventHandler, DdeAppCommandEventArgs e)
        {
            EventHandler<DdeAppCommandEventArgs> handle = eventHandler;
            if(handle != null) handle(this, e);
        }
        private void OnDebugMessageReceived(string source, string text) { HandleDdeAppCommandEventArgs(DebugMessageReceived, new DdeAppCommandEventArgs(source, text)); }
        private void OnRespondReceived(string source, string text) { HandleDdeAppCommandEventArgs(RespondReceived, new DdeAppCommandEventArgs(source, text)); }

        /// <summary>
        /// Occurs when raw Dde messages is received.
        /// </summary>
        public event EventHandler<DdeAppCommandsEventArgs> RawRespondReceived;
        private void OnRawRespondReceived(string source, IList<string> Messages)
        {
            EventHandler<DdeAppCommandsEventArgs> handle = RawRespondReceived;
            if(handle != null) handle(this, new DdeAppCommandsEventArgs(source, Messages));
        }

        /// <summary>
        /// Occurs when function call returned.
        /// </summary>
        public event EventHandler<DdeAppFunctionReturnEventArgs> FunctionReturned;
        private void OnFunctionReturned(string source, FunctionResult result)
        {
            EventHandler<DdeAppFunctionReturnEventArgs> handle = FunctionReturned;
            if(handle != null) handle(this, new DdeAppFunctionReturnEventArgs(source, result));
        }
        #endregion

        #region [ DdeClient Function ]
        private void OnLinkClosed(object sender, DdeDisconnectedEventArgs args)
        {
            DdeClient ptrClient = (DdeClient)sender;
            OnDisconnected(ptrClient.Service);
        }
        private void OnExecuteComplete(IAsyncResult result)
        {
            DdeClient client = (DdeClient)result.AsyncState;
            DdeClientItem ptrItem = Items[client.Service];
            if(ptrItem.Connected == true) 
                client.EndExecute(result); //Exception Handling
        }
        private void OnRequesetComplete(IAsyncResult result)
        {
            string SrcApp, DestApp, Keyword, DDECmd, tMessage;
            int tStatus = 0;
            string tStatusStr;

            DdeClient client = (DdeClient)result.AsyncState;    //Get DdeAppClient Pointer
            DdeClientItem ptrItem;
            ptrItem = Items[client.Service];
            if(ptrItem == null) return;

            //NDDE result processing
            byte[] data = client.EndRequest(result);            //Get DdeAppClient Messages
            string message = new System.Text.ASCIIEncoding().GetString(data);
            List<string> lines = new List<string>();
            lines.AddRange(message.Split('\n'));

            //Process Received Messages from DdeAppServer
            OnRawRespondReceived(ptrItem.Client.Service, lines);

            string tLine;
            for(int x = 0; x < lines.Count; x++)
            {
                ParamList.Clear();
                tLine = lines[x];

                if(string.IsNullOrEmpty(tLine) == true) continue;
                if(tLine == "\0") continue;

                tLine = tLine.Trim();
                ParamList.AddRange(tLine.Split());

                if(ParamList.Count < 4) continue;

                //message Protocol : <SRC> <DEST> DdeApp.<type> <Text>
                SrcApp = ParamList[0];
                DestApp = ParamList[1];
                Keyword = ParamList[2];
                DDECmd = ParamList[3];

                //DdeAppClient Verification
                if(DestApp != "_SYS_")
                {
                    if(string.Compare(_ApplicationName, DestApp, true) != 0) continue;
                }
                OnRespondReceived(SrcApp, tLine);

                DdeCommandType type = DdeShared.Keywords[Keyword];
                switch(type)
                {
                    case DdeCommandType.System:
                        if(DDECmd.CompareTo("CONNECTION_OPEN") == 0)
                        {
                            if(ParamList.Count == 5)
                            {
                                ptrItem.Version = ParamList[DdeShared.ParamPos - 1];
                                if(string.IsNullOrEmpty(ptrItem.Version) == false)
                                {
                                    ptrItem.Connected = true;
                                    OnConnected(ptrItem.Client.Service);
                                }
                            }
                        }
                        else if(DDECmd.CompareTo("SERVER_OFFLINE") == 0)
                        {
                            ptrItem.Connected = false;
                            if(ptrItem.Client.IsConnected == true) ptrItem.Client.Disconnect();
                            //OnLinkClosed triggered by NDDE
                        }
                        else if(DDECmd.CompareTo("SERVER_ONLINE") == 0)
                        {
                            OnServerOnline(SrcApp);
                        }
                        break;

                    case DdeCommandType.Function:
                        if(ParamList.Count < 5) continue;
                        if(ParamList.Count < 6) tMessage = "";
                        else tMessage = ParamList[DdeShared.ParamPos + 1];
                        tStatus = Convert.ToInt32(ParamList[DdeShared.ParamPos]);

                        if(WaitComplete(ptrItem.Client.Service, tStatus, tMessage) == false)
                            OnFunctionReturned(SrcApp, new FunctionResult(tStatus, tMessage));
                        break;

                    case DdeCommandType.Variable:
                        if(ParamList.Count < 7) continue;
                        tStatusStr = ParamList[DdeShared.ParamPos + 1];
                        if(tStatusStr == "OK") tStatus = 0;
                        else if(tStatusStr == "ERROR") tStatus = -10001;
                        else if(tStatusStr == "READONLY") tStatus = -10002;

                        //Compile Returned data in single strings
                        ParamList.RemoveRange(0, 6);
                        tMessage = string.Join(" ", ParamList.ToArray());

                        WaitComplete(ptrItem.Client.Service, tStatus, tMessage);
                        break;

                    case DdeCommandType.Info:
                        if(DebugMessageReceived != null)
                        {
                            ParamList.RemoveRange(0, DdeShared.ParamPos - 1);
                            OnDebugMessageReceived(ptrItem.Client.Service, string.Join(",", ParamList.ToArray()));
                        }
                        break;

                    case DdeCommandType.Error:
                        ParamList.RemoveRange(0, DdeShared.ParamPos - 1);
                        tMessage = string.Join(",", ParamList.ToArray());
                        WaitComplete(ptrItem.Client.Service, -10003, tMessage);
                        break;
                }
            }
        }
        #endregion
    }
}


