//---------------------------------------------------------------------------
#ifndef ClientControl_ItemH
#define ClientControl_ItemH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
#include "ClientMessages.h"
//---------------------------------------------------------------------------
typedef void (__closure *ClientClickEvent)(class TFClientControlItem *SenderForm);
class TFClientControlItem : public TForm
{
__published:	// IDE-managed Components
	TPanel *PN_Indicator;
	TShape *Ind_Rx;
	TShape *Ind_Tx;
	TShape *Ind_Select;
	TSpeedButton *Bt_Control;
	TTimer *RXTimer;
	TTimer *TXTimer;
	void __fastcall TXTimerTimer(TObject *Sender);
	void __fastcall RXTimerTimer(TObject *Sender);
	void __fastcall Bt_ControlClick(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);

private:	// User declarations
public:		// User declarations
	__fastcall TFClientControlItem(TComponent* Owner, AnsiString ClientName, int ClientHandle);
	int ddeHandle;

	TFClientMessages *ClientMessages;
	ClientClickEvent OnClientClick;

	void Flash_RXIndicator(void);
	void Flash_TXIndicator(void);

	void DisableAllControl();
};
//---------------------------------------------------------------------------
extern PACKAGE TFClientControlItem *FClientControlItem;
//---------------------------------------------------------------------------
#endif
