﻿namespace DdeApplicationTest
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.TxtSource = new System.Windows.Forms.TextBox();
            this.BtConnect = new System.Windows.Forms.Button();
            this.BtDisconnect = new System.Windows.Forms.Button();
            this.BtBrowse = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.TxtCommand = new System.Windows.Forms.TextBox();
            this.BtExecute = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(5, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(362, 316);
            this.listBox1.TabIndex = 0;
            // 
            // TxtSource
            // 
            this.TxtSource.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.TxtSource.Location = new System.Drawing.Point(5, 325);
            this.TxtSource.Name = "TxtSource";
            this.TxtSource.Size = new System.Drawing.Size(362, 20);
            this.TxtSource.TabIndex = 1;
            this.TxtSource.Text = "D:\\My Documents\\Programming\\Applications\\TestSystem\\Output\\bin\\Demo.exe";
            this.TxtSource.TextChanged += new System.EventHandler(this.TxtSource_TextChanged);
            // 
            // BtConnect
            // 
            this.BtConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtConnect.Location = new System.Drawing.Point(5, 351);
            this.BtConnect.Name = "BtConnect";
            this.BtConnect.Size = new System.Drawing.Size(75, 23);
            this.BtConnect.TabIndex = 2;
            this.BtConnect.Text = "Connect";
            this.BtConnect.UseVisualStyleBackColor = true;
            this.BtConnect.Click += new System.EventHandler(this.BtConnect_Click);
            // 
            // BtDisconnect
            // 
            this.BtDisconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtDisconnect.Location = new System.Drawing.Point(86, 351);
            this.BtDisconnect.Name = "BtDisconnect";
            this.BtDisconnect.Size = new System.Drawing.Size(75, 23);
            this.BtDisconnect.TabIndex = 2;
            this.BtDisconnect.Text = "Disconnect";
            this.BtDisconnect.UseVisualStyleBackColor = true;
            this.BtDisconnect.Click += new System.EventHandler(this.BtDisconnect_Click);
            // 
            // BtBrowse
            // 
            this.BtBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtBrowse.Location = new System.Drawing.Point(167, 351);
            this.BtBrowse.Name = "BtBrowse";
            this.BtBrowse.Size = new System.Drawing.Size(75, 23);
            this.BtBrowse.TabIndex = 2;
            this.BtBrowse.Text = "Browse";
            this.BtBrowse.UseVisualStyleBackColor = true;
            this.BtBrowse.Click += new System.EventHandler(this.BtBrowse_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // TxtCommand
            // 
            this.TxtCommand.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.TxtCommand.Location = new System.Drawing.Point(5, 394);
            this.TxtCommand.Name = "TxtCommand";
            this.TxtCommand.Size = new System.Drawing.Size(142, 20);
            this.TxtCommand.TabIndex = 3;
            // 
            // BtExecute
            // 
            this.BtExecute.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtExecute.Location = new System.Drawing.Point(153, 392);
            this.BtExecute.Name = "BtExecute";
            this.BtExecute.Size = new System.Drawing.Size(75, 23);
            this.BtExecute.TabIndex = 4;
            this.BtExecute.Text = "Execute";
            this.BtExecute.UseVisualStyleBackColor = true;
            this.BtExecute.Click += new System.EventHandler(this.BtExecute_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 417);
            this.Controls.Add(this.BtExecute);
            this.Controls.Add(this.TxtCommand);
            this.Controls.Add(this.BtBrowse);
            this.Controls.Add(this.BtDisconnect);
            this.Controls.Add(this.BtConnect);
            this.Controls.Add(this.TxtSource);
            this.Controls.Add(this.listBox1);
            this.Name = "Main";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox TxtSource;
        private System.Windows.Forms.Button BtConnect;
        private System.Windows.Forms.Button BtDisconnect;
        private System.Windows.Forms.Button BtBrowse;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox TxtCommand;
        private System.Windows.Forms.Button BtExecute;
    }
}

