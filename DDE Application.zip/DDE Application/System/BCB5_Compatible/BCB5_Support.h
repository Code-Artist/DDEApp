//---------------------------------------------------------------------------
#ifndef BCB5_SupportH
#define BCB5_SupportH
//---------------------------------------------------------------------------
#include <vcl.h>
//---------------------------------------------------------------------------
// BORLAND BUILDER 5 BACKWARD COMPATIBILITY SUPPORT MODULE
//---------------------------------------------------------------------------
AnsiString __fastcall AnsiReplaceStr(const AnsiString AText, const AnsiString AFromText, const AnsiString AToText);
void __fastcall SetDelimitedText(const AnsiString Source, TStringList *Dest, const char Delimiter);
AnsiString __fastcall GetDelimitedText(TStringList *Source, const char Delimiter);
//---------------------------------------------------------------------------
#endif
