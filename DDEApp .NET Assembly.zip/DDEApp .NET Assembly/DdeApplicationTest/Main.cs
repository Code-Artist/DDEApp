﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CodeArtEng.DdeApp;
using System.Diagnostics;

namespace DdeApplicationTest
{
    public partial class Main : Form
    {
        private DdeAppServer DdeServer;
        private DdeAppClient DdeClient;

        public Main()
        {
            InitializeComponent();
            listBox1.Items.Clear();
            DdeServer = DdeAppServer.SingleInstance(this);
            DdeServer.CommandReceived += new EventHandler<DdeAppCommandEventArgs>(DdeServer_CommandReceived);
            DdeServer.CommandSending += new EventHandler<DdeAppCommandEventArgs>(DdeServer_CommandSending);
            DdeServer.SetShutdownRequestCallback(DdeServerShutdownRequest);
            DdeServer.ClientConnected += new EventHandler<DdeAppEventArgs>(DdeServer_ClientConnected);
            DdeServer.ClientDisconnected += new EventHandler<DdeAppEventArgs>(DdeServer_ClientDisconnected);
            listBox1.Items.Add("Configured as Server");

            DdeClient = new DdeAppClient();
            DdeClient.ServerConnected += new EventHandler<DdeAppEventArgs>(DdeClient_ServerConnected);
            DdeClient.ServerDisconnected += new EventHandler<DdeAppEventArgs>(DdeClient_ServerDisconnected);
            DdeClient.FunctionReturned += new EventHandler<DdeAppFunctionReturnEventArgs>(DdeClient_FunctionReturned);
            DdeClient.RespondReceived += new EventHandler<DdeAppCommandEventArgs>(DdeClient_RespondReceived);
        }

        void DdeClient_RespondReceived(object sender, DdeAppCommandEventArgs e)
        {
            AddMessage(e.Text);
        }

        void DdeClient_FunctionReturned(object sender, DdeAppFunctionReturnEventArgs e)
        {
            AddMessage(e.Source + ": " + e.Result.Message);
        }

        void DdeClient_ServerDisconnected(object sender, DdeAppEventArgs e)
        {
            AddMessage("Server disconnected : " + e.Source);
        }

        void DdeClient_ServerConnected(object sender, DdeAppEventArgs e)
        {
            AddMessage("Server connected : " + e.Source);
        }


        #region [ Utility Functions ]
        private delegate void FormUpdate(string Msg);
        private void UpdateMessage(string Msg)
        {
            string[] lines = Msg.Split('\n');
            for(int x = 0; x < lines.Length; x++)
                listBox1.Items.Add(lines[x]);
        }
        void AddMessage(string message)
        {
            BeginInvoke(new FormUpdate(UpdateMessage), new object[] { message });
        }
        void DdeServer_CommandSending(object sender, DdeAppCommandEventArgs e)
        {
            AddMessage( "TX : " + e.Text );
        }
        void DdeServer_CommandReceived(object sender, DdeAppCommandEventArgs e)
        {
            AddMessage("RX : " + e.Text);
        }
        void DdeServerShutdownRequest() { Application.Exit(); }
        void DdeServer_ClientDisconnected(object sender, DdeAppEventArgs e)
        {
            AddMessage("Disconnected");
        }
        void DdeServer_ClientConnected(object sender, DdeAppEventArgs e)
        {
            AddMessage("Connnected");
        }
        
        #endregion

        private void BtBrowse_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                TxtSource.Text = openFileDialog1.FileName;
        }

        private string serverName = string.Empty;
        private void BtConnect_Click(object sender, EventArgs e)
        {
            if(serverName == string.Empty)
            {
                serverName = DdeClient.Add(TxtSource.Text, false);
            }
            DdeClient.Connect(serverName);
            //DdeClient.FunctionCall(serverName, "Help");
        }

        private void BtDisconnect_Click(object sender, EventArgs e)
        {
            if(serverName != string.Empty)
            {
                DdeClient.Disconnect(serverName);
                DdeClient.DeleteAll();
                serverName = string.Empty;
            }
        }

        private void TxtSource_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtExecute_Click(object sender, EventArgs e)
        {
            DdeClient.FunctionCall(serverName, TxtCommand.Text);
        }
    }
}
