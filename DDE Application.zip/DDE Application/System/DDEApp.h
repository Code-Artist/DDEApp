//---------------------------------------------------------------------------
#ifndef DDEAppH
#define DDEAppH
//---------------------------------------------------------------------------
#include <vcl.h>
#include <vector.h>
#include <DdeMan.hpp>
#include "CompilerVersion.h"
#include "ErrorManager.h"
//---------------------------------------------------------------------------
//#define SW_Development
//###########################################################################
//---------------------------------------------------------------------------
enum DDEVARTYPE{ dvInt, dvDouble, dvAnsiString};
//---------------------------------------------------------------------------
typedef int (__closure *DDEServerMessage)(TStrings *Commands);
typedef int (__closure *DDEClientDbgMsg)(AnsiString Source, AnsiString Message);
typedef int (__closure *DDEFunctionCall)(AnsiString Function, TStrings *Params, AnsiString *ReturnMessage);
typedef int (__closure *DDEVariableAccess) (AnsiString Variable, DDEVARTYPE Type, AnsiString *Value);
//---------------------------------------------------------------------------
class MDDEApp_Server
{
private:
	//Variables
	AnsiString DestApp, Keyword, DDECmd;

	//Private Objects
	AnsiString AppName;
	TDdeServerConv *DDEServer;
	TDdeServerItem *ServerData;
	TStringList *ResultBuffer;
	TStringList *ParamList;
	TStringList *ClientList;
	MErrorControl *Err;

	struct DFUNCTION
	{
		int ID;
		AnsiString Name;
		AnsiString Description;
	};
	int UniqueFuncID;
	vector <DFUNCTION *> Functions;

	struct DVARIABLE
	{
		int ID;
		AnsiString Name;
		bool ReadOnly;
		DDEVARTYPE Type;
		AnsiString Value;
	};
	int UniqueVarID;
	vector <DVARIABLE *> Variables;

	//Function
	int GetFunctionID(AnsiString Function);
	DVARIABLE *FindVariable(AnsiString Variable);
	void Func_Help(AnsiString Dest);
	void VariableCheck(DVARIABLE *ptr, AnsiString Operation);
	AnsiString DecodeErrorMsg(int ERRORID, int STATUS);

	void _Macro_System(TObject *Sender);
	void _Macro_Function(TObject *Sender);
	void _Macro_Variable(TObject *Sender);

	//Properties
	bool Enabled;
	int __fastcall GetClientListSize(void) { return ClientList->Count; };
	AnsiString __fastcall GetVersion(void);

	//TDdeServer Component's Events
	void __fastcall ClientConnected(TObject *Sender);
	void __fastcall ClientDisconnected(TObject *Sender);
	void __fastcall MacroProcessor(TObject *Sender, TStrings *Commands);

	MDDEApp_Server(TComponent *Owner);

public:
	static MDDEApp_Server *SingleInstance(TComponent *Owner); //Single Instance Constructor
	~MDDEApp_Server();

	//Functions
	void Online(void);
	void Offline(void);
	void Clients(TStrings *List); //Return list of connected client
	int RegisterFunction(AnsiString Name, AnsiString Description);
	int RegisterVariable(AnsiString Name, DDEVARTYPE Type, bool ReadOnly);
	void SendDbgMsg(AnsiString Text);
	__property AnsiString Version = { read = GetVersion };

	//Properties
	__property int ClientCount = { read = GetClientListSize };

	//Events
	TNotifyEvent OnClientConnect;
	TNotifyEvent OnClientDisconnect;
	TNotifyEvent OnClientShutdownQuery;
	DDEServerMessage OnReceive;
	DDEServerMessage OnSend;
	DDEFunctionCall OnFunctionCall;
	DDEVariableAccess OnVariableRead;
	DDEVariableAccess OnVariableWrite;
	DDEClientDbgMsg OnClientDbgMsg;
};
//---------------------------------------------------------------------------
extern MDDEApp_Server *DDEApp_Server;
//---------------------------------------------------------------------------
//###########################################################################
//---------------------------------------------------------------------------
typedef int DDEHANDLE;
typedef void (__closure *DDEClientEvent)(DDEHANDLE Handle);
typedef void (__closure *DDEClientMessages)(DDEHANDLE Handle, TStrings *Lines);
typedef void (__closure *DDEClientMessage)(DDEHANDLE Handle, AnsiString Message);
typedef void (__closure *DDEReturn)(DDEHANDLE Handle, int Status, AnsiString Message);
//---------------------------------------------------------------------------
struct DDEClientItem
{
	AnsiString Version;					//For version control usage.
	TDdeClientConv *DDEClient;
	TDdeClientItem *ClientData;
	AnsiString Buffer_DDEService;	//Application name without extension
	AnsiString Buffer_DDETopic; 	//Constant : "DEServer"
	AnsiString AppName;				//DDE Server Application File and Path
	bool AutoLaunch;
	bool Connected;
};
//---------------------------------------------------------------------------
class MDDEApp_Client
{
private:
	enum WAITTYPE { wtFunction, wtVariable };

	//Variables
	static int ObjectCount;
	int Status;
	TComponent *_Owner;
	AnsiString AppName;
	AnsiString SrcApp, DestApp, Keyword, DDECmd;

    //Internal Wait Loop's Variables
	DDEClientItem *_Wait_Object;
	bool _Wait_InLoop;
	bool _Wait_Timeout;
	int _Wait_Status;
	AnsiString _Wait_Message;
	WAITTYPE _Wait_Type;

	//Private Objects
	TStringList *ParamList;
	TStringList *MsgBuffer;
	TTimer *DDETimer;
	static MErrorControl *Err;

	vector <DDEClientItem *> Items;

	//Properties Access
	unsigned int __fastcall GetTimeout(void) { return DDETimer->Interval; };
	void __fastcall SetTimeout(unsigned int Value) { DDETimer->Interval = Value; };

	//Private Function
	bool VerifyHandle(DDEHANDLE Handle);
	bool DDEExecuteMacro(DDEClientItem *Sender, AnsiString Command);
	int WaitForEvent(WAITTYPE Type, DDEClientItem *Object, AnsiString *ReturnMessage);
	bool WaitComplete(DDEClientItem *Object, int Status, AnsiString Message);
	AnsiString DecodeErrorMsg(int ERRORID, int STATUS);
	AnsiString __fastcall GetLibVersion(void);

	//TDdeServer Component's Events
	void __fastcall OnTimeout(TObject *Sender);
	void __fastcall LinkOpened(TObject *Sender);
	void __fastcall LinkClosed(TObject *Sender);
	void __fastcall MessageReceived(TObject *Sender);

public:
	MDDEApp_Client(TComponent *Owner);
	~MDDEApp_Client();

	//Functions
	int Add(DDEHANDLE *Handle, AnsiString ApplicationName, bool AutoLaunch);
	void DeleteAll(void);
	int Connect(DDEHANDLE Handle);
	int Disconnect(DDEHANDLE Handle);
	int ShutDownServer(DDEHANDLE Handle);
	void ShutDownAllServer(void);
	__property AnsiString Version = { read = GetLibVersion };

	int FunctionCall(DDEHANDLE Handle, AnsiString Command);
	int FunctionCall(DDEHANDLE Handle, AnsiString Command, int *FunctionStatus, AnsiString *ReturnMessage);
	int VariableRead(DDEHANDLE Handle, AnsiString Variable, AnsiString *Value);
	int VariableWrite(DDEHANDLE Handle, AnsiString Variable, AnsiString Value);

	//Properties
	__property unsigned int Timeout = { read = GetTimeout, write = SetTimeout };
	AnsiString GetServiceName(DDEHANDLE Handle);
	AnsiString GetApplicationLocation(DDEHANDLE Handle);
	bool GetConnectStatus(DDEHANDLE Handle);
	AnsiString GetVersion(DDEHANDLE Handle);
	void GetServerList(TStringList *Servers, bool FullPath);

	//Events
	DDEClientEvent OnLinkClosed;
	DDEClientEvent OnServerOnline;	//Notify when server resume onlined
	DDEClientMessages OnSend;		//Message send to DDE Server
	DDEClientMessages OnReceive_Raw;	//Message received from DDE Server (RAW)
	DDEClientMessage OnReceive_Filtered; //Filtered receive message

	//Processed messages events
	DDEReturn OnFunctionReturn; 	//Function call return event.
	DDEClientMessage OnDbgMsg;		//Debug message

#ifdef SW_Development
	int DDE_ExecuteMacro(DDEHANDLE Handle, AnsiString Command); //Temp : for testing purpose
#endif

};
#endif
