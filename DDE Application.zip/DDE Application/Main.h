//---------------------------------------------------------------------------
#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
#include "ErrorManager.h"
#include "DDEApp.h"
#include <XPMan.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
#define MDI_BACKGROUND 0x00AE9990
//---------------------------------------------------------------------------
class TFDDEMain : public TForm
{
__published:	// IDE-managed Components
	TXPManifest *XPManifest1;
	TMainMenu *MainMenu;
	TMenuItem *Windows;
	TMenuItem *WindowCascade;
	TMenuItem *WindowTile;
	TPanel *DockPanel_Left;
	TSplitter *Splitter1;
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall WindowCascadeClick(TObject *Sender);
	void __fastcall WindowTileClick(TObject *Sender);

private:	// User declarations
	AnsiString SysPath;
	const AnsiString ConfigFile;
	const AnsiString AppName;

	bool FlgInit;

	TStringList *ConfigBuffer;
	void LoadConfiguration(void);
	void SaveConfiguration(void);

public:		// User declarations
	__fastcall TFDDEMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE MErrorReport *ErrReport;
extern PACKAGE MDDEApp_Client *DDEClients; //Declared in Main.cpp
extern PACKAGE TFDDEMain *FDDEMain;
//---------------------------------------------------------------------------
#endif
