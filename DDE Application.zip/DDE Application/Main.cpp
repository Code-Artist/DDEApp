//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Main.h"
#include "ClientControl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFDDEMain *FDDEMain;
MDDEApp_Client *DDEClients;
MErrorReport *ErrReport;
//---------------------------------------------------------------------------
__fastcall TFDDEMain::TFDDEMain(TComponent* Owner)
	: TForm(Owner),
	  AppName("DDE Application Network"),
	  ConfigFile("System\\Config.dat")
{
	SysPath = ExtractFilePath(ParamStr(0));

	//Create Objects
	ErrorManager = MErrorManager::SingleInstance(AppName);
	ErrorManager->Properties.ShowErrorMessage = false;

	DDEClients = new MDDEApp_Client(FDDEMain);
	ConfigBuffer = new TStringList;
	ErrReport = new MErrorReport;

	FlgInit = false;

	//Initialize GUI
	Caption = AppName + " (" + DDEClients->Version + ")";
	Brush->Color = TColor(MDI_BACKGROUND);
}
//---------------------------------------------------------------------------
void __fastcall TFDDEMain::FormActivate(TObject *Sender)
{
	DDEClients->Version;
	if(FlgInit == false)
	{
		FClientControl->ManualDock(DockPanel_Left, NULL, alTop);
		FClientControl->Show();

		//RunOnce when application loaded.
		LoadConfiguration();
		FlgInit = true;
    }
}
//---------------------------------------------------------------------------
void __fastcall TFDDEMain::FormDestroy(TObject *Sender)
{
	delete ConfigBuffer; ConfigBuffer = NULL;
	delete DDEClients; DDEClients = NULL;
	delete ErrReport; ErrReport = NULL;
	delete ErrorManager; ErrorManager = NULL;
}
//---------------------------------------------------------------------------
void __fastcall TFDDEMain::FormCloseQuery(TObject *Sender, bool &CanClose)
{
	//Confirm Closed (YES / NO / CANCEL)
	int tID;
	tID = Application->MessageBox("Quit Application?", "Comfirm", MB_YESNOCANCEL | MB_ICONQUESTION);
	if(tID != ID_YES){ CanClose = false; return; }

	SaveConfiguration();
	FClientControl->ShutDownAllClient();
	PostMessageA(FDDEMain, WM_CLOSE, NULL, NULL);
}
//---------------------------------------------------------------------------
void TFDDEMain::LoadConfiguration(void)
{
	if(FileExists(SysPath + ConfigFile) == false) return;

	ConfigBuffer->LoadFromFile(SysPath + ConfigFile);
	for(int x=0; x < ConfigBuffer->Count; x++)
		FClientControl->AddDDEClientItem(ConfigBuffer->Strings[x]);

	ErrorManager->Properties.ShowErrorMessage = true;
	ErrorManager->GetAllMessages();
	ErrorManager->Properties.ShowErrorMessage = false;
}
//---------------------------------------------------------------------------
void TFDDEMain::SaveConfiguration(void)
{
	ConfigBuffer->Clear();
	for(unsigned int x=0; x < FClientControl->Items.size(); x++)
		ConfigBuffer->Add(DDEClients->GetApplicationLocation(FClientControl->Items.at(x)->ddeHandle));

	//Create folder if not exists
	AnsiString tPath = ExtractFilePath(SysPath + ConfigFile);
	if(DirectoryExists(tPath) == false)
		CreateDir(tPath);

	ConfigBuffer->SaveToFile(SysPath + ConfigFile);
}
//---------------------------------------------------------------------------
// Main Menu
//---------------------------------------------------------------------------
void __fastcall TFDDEMain::WindowCascadeClick(TObject *Sender){ Cascade(); }
//---------------------------------------------------------------------------
void __fastcall TFDDEMain::WindowTileClick(TObject *Sender){ Tile(); }
//---------------------------------------------------------------------------

