//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "ClientMessages.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFClientMessages *FClientMessages;
//---------------------------------------------------------------------------
__fastcall TFClientMessages::TFClientMessages(TComponent* Owner, AnsiString ClientName)
	: TForm(Owner)
{
	Caption = ClientName;
	REd_Message->Clear();
	REd_Message->Paragraph->LeftIndent = 42;

	Params = new TStringList;
	Params->Delimiter = ' ';

	DDEMsgMap["DDE.System"] = mtSystem;
	DDEMsgMap["DDE.Function"] = mtFunction;
	DDEMsgMap["DDE.Variable"] = mtVariable;
	DDEMsgMap["DDE.Properties"] = mtProperties;
	DDEMsgMap["DDE.Info"] = mtInfo;
	DDEMsgMap["DDE.Error"] = mtError;
}
//---------------------------------------------------------------------------
void __fastcall TFClientMessages::FormDestroy(TObject *Sender)
{
	delete Params; Params = NULL;
}
//---------------------------------------------------------------------------
void TFClientMessages::AddMessage(TStrings *Lines)
{
	for(int x=0; x < Lines->Count; x++) AddMessage(Lines->Strings[x]);
}
//---------------------------------------------------------------------------
void TFClientMessages::AddMessage(AnsiString MessageData)
{
	AnsiString tPrefix;
	bool FlgReceiveMode = true;

	Params->Clear();
	Params->DelimitedText = MessageData;

	if(Params->Count < 3)
	{
		tPrefix = "[ NR ] ";
		REd_Message->SelAttributes->Color = clGray;
		REd_Message->Lines->Add(tPrefix + MessageData);
		return;
	}

	//DDE Application Message format "<SRC> <DEST> DDE.<TYPE> <Message>"
	//In TX Mode: SRC = Client
	if(Params->Strings[1].AnsiCompareIC(Caption) == NULL) FlgReceiveMode = false;
	//In RX Mode: DEST = Client
	else FlgReceiveMode = true;

	FlgReceiveMode == true ? tPrefix = "RX " : tPrefix = "TX ";

	DDEMsgType tMsgType = DDEMsgMap[Params->Strings[2]];
	switch(tMsgType)
	{
		case mtSystem:
			REd_Message->SelAttributes->Color = clYellow;
			tPrefix = tPrefix + "[SYS ]";
			break;

		case mtFunction:
			REd_Message->SelAttributes->Color = clLime;
			tPrefix = tPrefix + "[FUNC]";
			if((FlgReceiveMode == true) && (Params->Count > 4))
			{
				try{ if(Params->Strings[4].ToInt() < NULL) REd_Message->SelAttributes->Color = clRed; }
				catch(Exception *e){ REd_Message->SelAttributes->Color = clRed; }
			}
			break;

		case mtVariable:
			REd_Message->SelAttributes->Color = clLime;
			tPrefix = tPrefix + "[VAR ]";
			if(Params->Count > 5)
			{
				if(Params->Strings[5].AnsiCompareIC("OK") != NULL)
					REd_Message->SelAttributes->Color = clRed;
			}
			break;

		case mtProperties:
			tPrefix = tPrefix + "[PROP]";
			REd_Message->SelAttributes->Color = clLime;
			break;

		case mtInfo:
			tPrefix = tPrefix + "[INFO]";
			REd_Message->SelAttributes->Color = clSkyBlue;
			break;

		case mtError:
			tPrefix = tPrefix + "[ERR ]";
			REd_Message->SelAttributes->Color = clRed;
			break;

		default:
			REd_Message->SelAttributes->Color = clGray;
			REd_Message->Lines->Add(tPrefix + MessageData);
	}

	for(int x=0; x < 3; x++) Params->Delete(0);
	REd_Message->Lines->Add(tPrefix + "  " + Params->DelimitedText);
	Application->ProcessMessages();
}
//---------------------------------------------------------------------------
void TFClientMessages::AddMessage_Raw(AnsiString Message){ REd_Message->Lines->Add(Message); }
//---------------------------------------------------------------------------
void TFClientMessages::AddErrorMessages(MErrorReport *Report)
{
	AnsiString tMessage;
	REd_Message->SelAttributes->Color = clRed;
	for(unsigned int x=0; x < Report->Items.size(); x++)
	{
		tMessage = AnsiString("[ERROR] ") + Report->Items.at(x)->Function + " " +
						Report->Items.at(x)->Message + " (" + Report->Items.at(x)->StatusCode + ")";
		REd_Message->Lines->Add(tMessage);
    }
}
//---------------------------------------------------------------------------
void __fastcall TFClientMessages::REd_MessageChange(TObject *Sender)
{
	REd_Message->Perform(EM_SCROLLCARET, NULL, NULL);
	REd_Message->Perform(EM_LINESCROLL, NULL, 1);
}
//---------------------------------------------------------------------------
// Sub Menu
//---------------------------------------------------------------------------
void __fastcall TFClientMessages::MsgClearClick(TObject *Sender){ REd_Message->Clear(); }
//---------------------------------------------------------------------------
void __fastcall TFClientMessages::SaveToFileClick(TObject *Sender)
{
	if(FileSaveDlg->Execute() == true)
	{
		if(ExtractFileExt(FileSaveDlg->FileName).AnsiCompareIC(".txt") != NULL)
			FileSaveDlg->FileName = FileSaveDlg->FileName + ".txt";

		TStringList *OutputBuffer = new TStringList;
		AnsiString Title = AnsiString("[") + TDateTime().CurrentDateTime().DateTimeString() + "] " + Caption;
		OutputBuffer->Text = Title;
		REd_Message->WordWrap = false;
		OutputBuffer->AddStrings(REd_Message->Lines);
		OutputBuffer->SaveToFile(FileSaveDlg->FileName);
		REd_Message->WordWrap = true;
		delete OutputBuffer; OutputBuffer = NULL;
	}
}
//---------------------------------------------------------------------------

