//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("Main.cpp", FDDEMain);
USEFORM("Forms\ClientControl.cpp", FClientControl);
USEFORM("Forms\ClientControl_Item.cpp", FClientControlItem);
USEFORM("Forms\ClientMessages.cpp", FClientMessages);
USEFORM("Forms\DDE_ControlPanel.cpp", FDDEControlPanel);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	try
	{
		Application->Initialize();
		Application->CreateForm(__classid(TFDDEMain), &FDDEMain);
		Application->CreateForm(__classid(TFClientControl), &FClientControl);
		Application->CreateForm(__classid(TFDDEControlPanel), &FDDEControlPanel);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
