//---------------------------------------------------------------------------
#pragma hdrstop
#include "DDEApp.h"
//---------------------------------------------------------------------------
#ifndef COMPILER_BCB5
	#include <StrUtils.hpp>
#else
	#define DELIMITER ' '
	#include "BCB5_Support.h"
#endif
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
// PRIVATE Variable and Functions
//---------------------------------------------------------------------------
enum DDECMDTYPE { dmSystem, dmFunction, dmVariable, dmInfo, dmError };
struct KW_XREF { char *Name; int ID; };
const static int ParamPos = 4;
const static int DDE_ERROR = -99; //Dummy Error Code
const static AnsiString _Version = "1.3.14";
//---------------------------------------------------------------------------
KW_XREF DDEKwRef[] = { "DDE.System", dmSystem, 			//System Specified Message (Hidden to user?)
						 "DDE.Function", dmFunction,	//Function Execution
						 "DDE.Variable", dmVariable,			//Variable Access
						 "DDE.Info", dmInfo,            //Information for user. Not for processing
						 "DDE.Error", dmError};
int DDEKwRefSize = sizeof(DDEKwRef) / sizeof(KW_XREF);
//---------------------------------------------------------------------------
KW_XREF DDEVarRef[] = { "Integer", dvInt,
						"Double", dvDouble,
						"AnsiString", dvAnsiString};
int DDEVarRefSize = sizeof(DDEVarRef) / sizeof(KW_XREF);
//---------------------------------------------------------------------------
int GetKeywordID(KW_XREF *Ref, int RefSize, AnsiString String)
{
	/************************************************************************
	 DESC	: Retrieve Keyword ID from KW_XREF structure type based name. 
	************************************************************************/
	int XrefSize = RefSize;
	for(int x=0; x < XrefSize; x++)
		if(String.AnsiCompareIC(Ref[x].Name) == NULL) return Ref[x].ID;
	return DDE_ERROR;
}
//---------------------------------------------------------------------------
AnsiString FmtDDEMessage(AnsiString SrcApp, AnsiString DestApp, DDECMDTYPE Type, AnsiString Message)
{
	/************************************************************************
	 DESC	: Format DDE Message in a predefined format. 
	************************************************************************/
	//Compile DDE Application Message in format "<SRC> <DEST> DDE.<TYPE> <Message>"
	AnsiString Result;
	int XrefSize = sizeof(DDEKwRef)/sizeof(KW_XREF);
	for(int x=0; x < XrefSize; x++)
	{
		if(Type == DDEKwRef[x].ID)
			return Result = SrcApp + " " + DestApp  + " " +	DDEKwRef[x].Name + " " + Message;
	}
	return "";
}
//---------------------------------------------------------------------------
//###########################################################################
// CLASS : DDE SERVER
//###########################################################################
//---------------------------------------------------------------------------
MDDEApp_Server *DDEApp_Server = NULL;
MDDEApp_Server *MDDEApp_Server::SingleInstance(TComponent *Owner)
{
	/************************************************************************
	 NOTE: DDE Server only allow single instance. for ecah application.
	 Subsequent creation of DDE Server is not allowed.
	 ------------------------------------------------------------------------
	 INPUT:
	 - OWNER : Use Main Form as owner in order for DDE to work.
	************************************************************************/
	if(DDEApp_Server == NULL) DDEApp_Server = new MDDEApp_Server(Owner);
	return DDEApp_Server;
}
//---------------------------------------------------------------------------
AnsiString __fastcall MDDEApp_Server::GetVersion(){ return _Version; }
MDDEApp_Server::MDDEApp_Server(TComponent *Owner)
	: UniqueFuncID(10),
	  UniqueVarID(100)
{
	//Register Application Name to DDE Server
	AppName = ExtractFileName(ParamStr(0));
	AnsiString tExt = ExtractFileExt(ParamStr(0));
	AppName = AnsiReplaceStr(AppName, tExt, "");

	//Initialize Error Control
	Err = new MErrorControl("MDDEApp_Server");
	Err->DecodeErrorMsg = DecodeErrorMsg;

	//Initialize DDE Server
	ServerData = new TDdeServerItem(Owner);
	DDEServer = new TDdeServerConv(Owner);
	DDEServer->Name = "DDEServer";
	ServerData->Name = "ServerData";
	ServerData->ServerConv = DDEServer;

	//Assign DDE Server Event
	DDEServer->OnOpen = ClientConnected;
	DDEServer->OnClose = ClientDisconnected;
	DDEServer->OnExecuteMacro = MacroProcessor;

	//Initialize Callback Function Pointer
	OnClientConnect = NULL;
	OnClientDisconnect = NULL;
	OnClientShutdownQuery = NULL;
	OnReceive = NULL;
	OnSend = NULL;
	OnFunctionCall = NULL;
	OnVariableRead = NULL;
	OnVariableWrite = NULL;
	OnClientDbgMsg = NULL;

	//Initialize Local Variable
	ResultBuffer = new TStringList;
	ParamList = new TStringList;
    #ifndef COMPILER_BCB5
	ParamList->Delimiter = ' ';
    #endif
	ClientList = new TStringList;
	ClientList->Sorted = true;
	ClientList->Duplicates = dupIgnore;

	//Initialize Server Status
	Online();

	RegisterFunction("Help", "");
	RegisterFunction("HideMainForm", "");
	RegisterFunction("RestoreWindow", "");
	RegisterFunction("MinimizeWindow", "");
	RegisterFunction("BringToFront", "");
	RegisterFunction("SetWindowPosition", "<X> <Y>");

	RegisterVariable("FunctionList", dvAnsiString, true);
	RegisterVariable("VariableList", dvAnsiString, true);
}
//---------------------------------------------------------------------------
MDDEApp_Server::~MDDEApp_Server()
{
	/************************************************************************
	 NOTE: Do not call destructor or attempt to delete DDE Server when
	 application is running. This will cause unexpected behaviour
	 in DDE Manager (TDdeMgr *DdeMgr).
	 Free Object using delete when terminating application.
	************************************************************************/
	Offline();

	delete ServerData;
	delete DDEServer;
	delete ResultBuffer;
	delete ParamList;
	delete ClientList;
	delete Err;

	DDEServer = NULL;
	ServerData = NULL;
	ResultBuffer = NULL;
	ParamList = NULL;
	ClientList = NULL;
	Err = NULL;

	//Unregister Function List
	for(unsigned int x=0; x < Functions.size(); x++)
		delete Functions.at(x);
	Functions.clear();

	//Unregister Variables List
	for(unsigned int x=0; x < Variables.size(); x++)
		delete Variables.at(x);
	Variables.clear();
}
//---------------------------------------------------------------------------
// SECTION : Server Private Functions
//---------------------------------------------------------------------------
AnsiString MDDEApp_Server::DecodeErrorMsg(int ERRORID, int STATUS)
{
	/************************************************************************
	 DESC	: Decode Error Message
	 ------------------------------------------------------------------------
	 NOTE:
	 - Handling User called function's error.
	 - DDE communication error not handled by ERRORCONTROL module
	************************************************************************/
	if(ERRORID == Err->ErrorID)
	{
		switch(STATUS)
		{
			case -1: return AnsiString("Unable to register function [ %1 ]. Function name must be single word!");
			case -2: return AnsiString("Unable to register function [ %1 ]. Function previously registered!");

			case -11: return AnsiString("Unable to register variable [ %1 ]. Variable name must be single word!");
			case -12: return AnsiString("Unable to register variable [ %1 ]. Variable previously registered!");
			default: return AnsiString("Unknown Error!");
		}
	}
	else return AnsiString("Unknown Error. ERROR ID Not belong to this class!");
}
//---------------------------------------------------------------------------
int MDDEApp_Server::GetFunctionID(AnsiString Function)
{
	/************************************************************************
	 DESC	: Retreive the unique function ID of registered function name.
			  Negative value returned if function is not registered.
	************************************************************************/
	for(unsigned int x=0; x < Functions.size(); x++)
	{
		if(Functions.at(x)->Name.AnsiCompareIC(Function) == NULL)
			return Functions.at(x)->ID;
	}
	return DDE_ERROR;
}
//---------------------------------------------------------------------------
MDDEApp_Server::DVARIABLE *MDDEApp_Server::FindVariable(AnsiString Variable)
{
	/************************************************************************
	 DESC	: Find Variable
	 ------------------------------------------------------------------------
	 NOTE: Search variable with Name. Pointer of variable structure is 
	 returned on success. Returned value is set to NULL if variable
	 not found in Variable list.
	************************************************************************/
	for(unsigned int x=0; x < Variables.size(); x++)
	{
		if(Variables.at(x)->Name.AnsiCompareIC(Variable) == NULL)
			return Variables.at(x);
	}
	return NULL;
}
//---------------------------------------------------------------------------
void MDDEApp_Server::Func_Help(AnsiString Dest)
{
	/************************************************************************
	 DESC	: Help Screen
	 ------------------------------------------------------------------------
	 CONTENT:
	 - DDE Application Protocol version.
	 - DDE Application protocol and usage guide.
	 - Show Registered Function and Description (Application specified)
	 - Show Registered Variables and Type (Application specified)
	************************************************************************/
	#define ResultAdd(Message) ResultBuffer->Add(FmtDDEMessage(AppName, Dest, dmInfo, Message));

	ResultAdd("<<<< DDE APPLICATION (" + AppName + ") Version : " + Version + " >>>>");
	ResultAdd("Usage: <Source> <Dest> <Commands>");
	ResultAdd("  ");
	ResultAdd("<Source> : Sender Application EXE Name");
	ResultAdd("<Dest>   : Receiver Application EXE Name");
	ResultAdd("<Cmds>   : [DDE.Function, DDE.Variable]");
	ResultAdd("  ");
	ResultAdd("#### Function Call ####");
	ResultAdd("  - SEND    : DDE.Function <FunctionName> [Param1] ... [ParamN]");
	ResultAdd("  - RECEIVE : DDE.Function <FunctionName> <Status> [Return Message]");
	ResultAdd("  ");
	ResultAdd("#### Variable Access ####");
	ResultAdd("  - SEND    : DDE.Variable <Read/Write> <VariableName> [Value]");
	ResultAdd("  - RECEIVE : DDE.Variable Read <VariableName> <Status> <Value>");
	ResultAdd("  -           DDE.Variable Write <VariableName> <Status> <Value>");
	ResultAdd("  ");
	ResultAdd("#### FUNCTIONS ####");
		for(unsigned int x=0; x < Functions.size(); x++)
			ResultAdd("\t" + Functions.at(x)->Name + "\t" + Functions.at(x)->Description);

	ResultAdd("   ");
	ResultAdd("#### VARIABLES ####");
		if(Variables.size() == NULL) ResultAdd("\t<NONE>");
		for(unsigned int x=0; x < Variables.size(); x++)
		{
			AnsiString tAttr, tType;
			switch(Variables.at(x)->Type)
			{
				case dvInt: tType = "Int"; break;
				case dvDouble: tType = "Double"; break;
				case dvAnsiString: tType = "AnsiString"; break;
			}

			Variables.at(x)->ReadOnly == true ? tAttr = "R" : tAttr = "RW";
			ResultAdd("\t" + Variables.at(x)->Name + "\t" + tType + " " + tAttr);
		}
	ResultAdd("   ");
	ResultAdd("<<<< END >>>>");
}
//---------------------------------------------------------------------------
void MDDEApp_Server::VariableCheck(DVARIABLE *Var, AnsiString Operation)
{
	/************************************************************************
	 DESC	: Variable Check
	 ------------------------------------------------------------------------
	 NOTE: Compare and check variable type of returned value on 
	 read and write access with Registered Type. Error raised
	 if invalid type is detected.
	************************************************************************/
	bool tVarValid = true;
	//Return Value Type Check
	switch(Var->Type)
	{
		case dvInt:
			try{ Var->Value.ToInt(); }
			catch(Exception *e)
			{
				ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
					Operation + " " + Var->Name + " : Invalid Int Value!"));
				tVarValid = false;
			}
			break;

		case dvDouble:
			try{ Var->Value.ToDouble(); }
			catch(Exception *e)
			{
				ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
					Operation + " " + Var->Name + " : Invalid Double Value!"));
				tVarValid = false;
			}
			break;

		case dvAnsiString:
			//Quote strings.
			if(Var->Value.AnsiPos(" ") != NULL)
				Var->Value = AnsiQuotedStr(Var->Value, '"');
			break;
	}
	if(tVarValid == true)
	{
		//Variable Check Success. Return Value to Client
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmVariable,
			Operation + " " + Var->Name + " OK " + Var->Value));
	}
}
//---------------------------------------------------------------------------
// SECTION : Server Functions
//---------------------------------------------------------------------------
/***************************************************************
 TITLE	: Online / Offline
 AUTHOR : MAI
 DATE   : 24/10/08
--------------------------------------------------------------
 DESCRIPTION:
 Enable to switch DDE Server ON / OFF virtually.
 Online : Client allow to connect and talk to server
 Offline : Client will be informed that server is offline and
	subsequent DDE message from client would not be processed

 NOTE: Unless Client called CloseLink(), the link is still
	established even Server go Offline as DDE server unable
	to close link (Do not delete DDE Server!!).
--------------------------------------------------------------
 HISTORY:
***************************************************************/
void MDDEApp_Server::Online(void)
{
	Enabled = true;
	ResultBuffer->Clear();
	ResultBuffer->Add(FmtDDEMessage(AppName, "_SYS_", dmSystem, "SERVER_ONLINE"));

	//Return Messages to Client
	if(OnSend) OnSend(ResultBuffer);
	ServerData->Text = "";
	ServerData->Lines->Clear();
	ServerData->Lines->AddStrings(ResultBuffer);
}
//---------------------------------------------------------------------------
void MDDEApp_Server::Offline(void)
{
	/************************************************************************
	 DESC	: Online / Offline
	 ------------------------------------------------------------------------
	 NOTE: Enable to switch DDE Server ON / OFF virtually.
	 > Online : Client allow to connect and talk to server
	 > Offline : Client will be informed that server is offline and
		subsequent DDE message from client would not be processed

	 > Unless Client called CloseLink(), the link is still
	 established even Server go Offline as DDE server unable
	 to close link (Do not delete DDE Server!!).
	************************************************************************/
	Enabled = false;
	ClientList->Clear(); //Remove all Clients when Server go offline

	//Update Result to Server Data
	ResultBuffer->Clear();
	ResultBuffer->Add(FmtDDEMessage(AppName, "_SYS_", dmSystem, "SERVER_OFFLINE"));

	//Return Messages to Client
	if(OnSend) OnSend(ResultBuffer);
	ServerData->Text = "";
	ServerData->Lines->Clear();
	ServerData->Lines->AddStrings(ResultBuffer);
}
//---------------------------------------------------------------------------
int MDDEApp_Server::RegisterFunction(AnsiString Name, AnsiString Description)
{
	/************************************************************************
	 DESC	: Register Function
	 ------------------------------------------------------------------------
	 NOTE: Register user specified function for the usage of DDE Client.
	 An unique function ID is given to each successfully registered
	 function.

	 INPUT:
	 - Name : Function Name (Single Word only)
	 - Description : Short summay of registered function. Show in HELP screen.
	************************************************************************/
	if(Name.AnsiPos(" ") != NULL) return Err->RaiseError(-1, "RegisterFunction", Name);

	//Validate Name is unique
	for(unsigned int x=0; x < Functions.size(); x++)
		if(Functions.at(x)->Name.AnsiCompareIC(Name) == NULL)
			return Err->RaiseError(-2, "RegisterFunction", Name);

	DFUNCTION *Func = new DFUNCTION;
	Func->Name = Name;
	Func->ID = UniqueFuncID++;
	Func->Description = Description;
	Functions.push_back(Func);
	return NULL;
}
//---------------------------------------------------------------------------
int MDDEApp_Server::RegisterVariable(AnsiString Name, DDEVARTYPE Type, bool ReadOnly)
{
	/************************************************************************
	 DESC	: Register Variable
	 ------------------------------------------------------------------------
	 NOTE: Register Server variable for Client access.
	 An unique function ID is given to each successfully registered
	 function.
	 Variable are stored in AnsiString format regardless its type.

	 INPUT:
	 - Name : Variable Name (Single Word Only)
	 - Type : Variable Type (Refer DDEVARTYPE)
	 - ReadOnly : Set read only to prevent client to modify content.
	************************************************************************/
	if(Name.AnsiPos(" ") != NULL) return Err->RaiseError(-11, "RegisterVariable", Name);

	//Validate Name is unique
	for(unsigned int x=0; x < Variables.size(); x++)
		if(Variables.at(x)->Name.AnsiCompareIC(Name) == NULL) return Err->RaiseError(-12, "RegisterVariable", Name);

	DVARIABLE *Var = new DVARIABLE;
	Var->Name = Name;
	Var->ID = UniqueVarID++;
	Var->ReadOnly = ReadOnly;
	Var->Type = Type;
	Var->Value = NULL;
	Variables.push_back(Var);
	return NULL;
}
//---------------------------------------------------------------------------
void MDDEApp_Server::Clients(TStrings *List)
{
	if(List == NULL) return;
	List->AddStrings(ClientList);
}
//---------------------------------------------------------------------------
void MDDEApp_Server::SendDbgMsg(AnsiString Text)
{
	/************************************************************************
	 DESC	: Send Comment
	 ------------------------------------------------------------------------
	 NOTE: Send general information / comment using DDE.Info type to client.
	 Useful for debug purpose
	************************************************************************/
	ResultBuffer->Add(FmtDDEMessage(AppName, "_SYS_", dmInfo, Text));

	//Update to Server
	if(OnSend) OnSend(ResultBuffer);
	ServerData->Text = "";
	ServerData->Lines->Clear();
	ServerData->Lines->AddStrings(ResultBuffer);
}
//---------------------------------------------------------------------------
// SECTION : DDE Server Events
//---------------------------------------------------------------------------
void __fastcall MDDEApp_Server::ClientConnected(TObject *Sender)
{
	/************************************************************************
	 DESC	: Client Connected Event
	 ------------------------------------------------------------------------
	 NOTE: 
	 - Attached to TDdeServer::OnOpen() to get notified by
	 TDdeServer component when client connection detected.
	 - Connection between Server and Client is only connected
	 successfully when Server received system message "Connect" 
	 from Client. 
	************************************************************************/

	ServerData->Text = AnsiString(); //Clear data content
	//Used execute Macro to identify connected client
}
//---------------------------------------------------------------------------
void __fastcall MDDEApp_Server::ClientDisconnected(TObject *Sender)
{
	/************************************************************************
	 Used execute Macro to identify client who disconnected
	 Abnormal shut down of DDEClient would not be taken care.
	************************************************************************/
}
//---------------------------------------------------------------------------
void __fastcall MDDEApp_Server::MacroProcessor(TObject *Sender, TStrings *Commands)
{
	/************************************************************************
	 DESC	: Client Execute Macro Event
	 ------------------------------------------------------------------------
	 NOTE: Attached to TDdeServer::OnExecuteMacro() to get notified when
	 TDdeServer component receive Macro execution from client.
	************************************************************************/
	AnsiString ClientName;
	AnsiString tCmd;
	ResultBuffer->Clear();

	//DDE Server Bus Monitor
	if(OnReceive) OnReceive(Commands);

	for(int x=0; x < Commands->Count; x++)
	{
		//Skip Empty Line
		tCmd = Commands->Strings[x];
		if(Commands->Strings[x].IsEmpty() == true) continue;

		//Decode Commands
		ParamList->Clear();

		#ifndef COMPILER_BCB5
			ParamList->DelimitedText = tCmd;
		#else
			SetDelimitedText(tCmd, ParamList, DELIMITER);
		#endif

		//Special access for non statndard DDE protocol
		if(ParamList->Strings[0].AnsiCompareIC("Help") == NULL)
		{
			Func_Help("_SYS_");
			AnsiString tFuncReturn = "Help 0 OK";
			ResultBuffer->Add(FmtDDEMessage(AppName, "_SYS_", dmFunction, tFuncReturn));

			//Update to Server
			if(OnSend) OnSend(ResultBuffer);
			ServerData->Text = "";
			ServerData->Lines->Clear();
			ServerData->Lines->AddStrings(ResultBuffer);
			return;
		}

		//Check for minimum param size
		if(ParamList->Count < 4) continue;

		// Message Protocol : <SRC> <DEST> DDE.<Type> <Command>
		DestApp = ParamList->Strings[0];
		Keyword = ParamList->Strings[2];
		DDECmd = ParamList->Strings[3];

		//Check Server Status
		if(Enabled == false)
		{
			ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError, "Server Offlined."));
			ClientList->Add(DestApp);

			if(OnSend) OnSend(ResultBuffer);
			ServerData->Text = "";
			ServerData->Lines->Clear();
			ServerData->Lines->AddStrings(ResultBuffer);
			continue;
		}

		//Internal Process
		switch(GetKeywordID(DDEKwRef, DDEKwRefSize, Keyword))
		{
			case dmSystem: _Macro_System(Sender); break;
			case dmFunction: _Macro_Function(Sender); break;
			case dmVariable: _Macro_Variable(Sender); break;
			case dmInfo:
				if(OnClientDbgMsg)
				{
					for(int x=0; x < ParamPos - 1; x++) ParamList->Delete(0); //Remove Protocol Header
					OnClientDbgMsg(DestApp, ParamList->Text);
				}
		}
	}

	//Update Result to Server Data
	if(ResultBuffer->Text.IsEmpty() == false)
	{
		//Update to Server
		if(OnSend) OnSend(ResultBuffer);
		ServerData->Text = "";
		ServerData->Lines->Clear();
		ServerData->Lines->AddStrings(ResultBuffer);
	}

}
//---------------------------------------------------------------------------
void MDDEApp_Server::_Macro_System(TObject *Sender)
{
	/************************************************************************
	 DESC	: Internal Macro Process : SYSTEM
	 ------------------------------------------------------------------------
	 NOTE: System Message. Defined internally to handle DDE connection.
	 Not accessibly directly by user. User will only get
	 notified by event. 
	************************************************************************/

	if(DDECmd.AnsiCompareIC("Connect") == NULL)
	{
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmSystem, "CONNECTION_OPEN " + Version));
		ClientList->Add(DestApp); //Register Client

		//EVENT : Connection Established
		if(OnClientConnect) OnClientConnect(Sender);
	}
	else if(DDECmd.AnsiCompareIC("Disconnect") == NULL)
	{
		int tIndex;

		//Unregister Client
		if(ClientList->Find(DestApp,tIndex) == true)
			ClientList->Delete(tIndex);

		//EVENT : Connection Terminated 
		if(OnClientDisconnect) OnClientDisconnect(Sender);
	}
	else if(DDECmd.AnsiCompareIC("Shutdown") == NULL)
	{
		//Shut down request send from client to server.
		//Server had to decide whether to shut down. (User Implementation)

		//EVENT : Client Request Server to Shut Down. User decide to shut down or not 
		if(OnClientShutdownQuery) OnClientShutdownQuery(Sender);
		else ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError, "Shutdown Failed! Function Not Implemented!"));
	}
}
//---------------------------------------------------------------------------
void MDDEApp_Server::_Macro_Function(TObject *Sender)
{
	/************************************************************************
	 DESC	: Internal Macro Process : Function
	 ------------------------------------------------------------------------
	 NOTE: DDE Application's Function call. Only pre-registered function
	 will be send to user for further processing. System defined
	 function will be process internally.
	************************************************************************/
	AnsiString tFuncReturn;

	//Check Client Connection Status
	if(ClientList->IndexOf(DestApp) == -1)
	{
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError, "Server Not Connected!"));
		return;
	}

	//=============== INTERNAL REGISTERED FUNCTION ===============
	if(DDECmd.AnsiCompareIC("Help") == NULL)
	{
		//Return Header, Registered Functions and Data
		Func_Help(DestApp);
		tFuncReturn = DDECmd + " 0 " + "OK";
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmFunction, tFuncReturn));
	}
	else if(DDECmd.AnsiCompareIC("HideMainForm") == NULL)
	{
        Application->MainForm->Hide();
		tFuncReturn = DDECmd + " 0 " + "OK";
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmFunction, tFuncReturn));
	}
	else if(DDECmd.AnsiCompareIC("RestoreWindow") == NULL)
	{
		Application->Restore();
		ShowWindow(Application->MainForm, SW_RESTORE);
		if(Application->MainForm->Visible == false) Application->MainForm->Show();
		tFuncReturn = DDECmd + " 0 " + "OK";
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmFunction, tFuncReturn));
	}
	else if(DDECmd.AnsiCompareIC("MinimizeWindow") == NULL)
	{
		Application->Minimize();
		ShowWindow(Application->MainForm, SW_MINIMIZE);
		tFuncReturn = DDECmd + " 0 " + "OK";
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmFunction, tFuncReturn));
	}
	else if(DDECmd.AnsiCompareIC("BringToFront") == NULL)
	{
		Application->Restore();			//Restore Minimized Window before bring to front
		ShowWindow(Application->MainForm, SW_RESTORE);
		Application->BringToFront();
		if(Application->MainForm->Visible == false) Application->MainForm->Show();
		tFuncReturn = DDECmd + " 0 " + "OK";
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmFunction, tFuncReturn));
	}
	else if(DDECmd.AnsiCompareIC("SetWindowPosition") == NULL)
	{
		//Remove header. Only forward function parameter.
		for(int y=0; y < ParamPos; y++) ParamList->Delete(0);

		if(ParamList->Count < 2)
		{
			Application->MainForm->Left = 0;
			Application->MainForm->Top = 0;
		}
		else
		{
			//Set X Position
			try{ Application->MainForm->Left = ParamList->Strings[0].ToInt(); }
			catch(Exception *e){ Application->MainForm->Left = 0; }

            //Set Y Position
			try{ Application->MainForm->Top = ParamList->Strings[1].ToInt(); }
			catch(Exception *e){ Application->MainForm->Top = 0; }
		}
		tFuncReturn = DDECmd + " 0 " + "OK " + Application->MainForm->Left + " " + Application->MainForm->Top;
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmFunction, tFuncReturn));
	}
	//============================================================

	else if(GetFunctionID(DDECmd) > NULL)
	{
		//USER SPECIFIED FUNCTION
		if(OnFunctionCall)
		{
			int tFuncStatus;
			AnsiString tFuncReturn;

			//Remove header. Only forward function parameter.
			for(int y=0; y < ParamPos; y++) ParamList->Delete(0);

			try
			{
				//Function execution
				tFuncStatus = OnFunctionCall(DDECmd, ParamList, &tFuncReturn);
				tFuncReturn = DDECmd + " " + tFuncStatus + " " + AnsiQuotedStr(tFuncReturn, '"');
				ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmFunction, tFuncReturn));
			}
			catch(Exception &ex)
			{
				tFuncStatus = -1001;
				tFuncReturn = DDECmd + " " + tFuncStatus + " " + ex.Message;
				ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError, tFuncReturn));
			}
		}
		else
		{
			//Raised Error when OnFunctionCall not implemented
			ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
				AnsiString("OnFunctionCall() Event not implemented! Function not executed!")));
		}
	}
	else
	{
		//Raised Error for unhandled Function
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
			AnsiString("Unable to proceed! Function not registered : [") + DDECmd + "]"));
	}
}
//---------------------------------------------------------------------------
void MDDEApp_Server::_Macro_Variable(TObject *Sender)
{
	/************************************************************************
	 DESC	: Internal Macro Process : VARIABLE
	 ------------------------------------------------------------------------
	 Control access of registered variable and its read / write
	 operation. Returned value of read / write operation for each
	 variable will be check for its type before acknowledge to
	 Client.
	************************************************************************/
	DVARIABLE *ptrVar;

	//Check Client Connection Status
	if(ClientList->IndexOf(DestApp) == -1)
	{
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError, "Server Not Connected!"));
		return;
	}

	//Variable Name check
	if(ParamList->Count < 5)
	{
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
			"Missing Variable Name!"));
		return;
	}

	//Verify Variable
	ptrVar = FindVariable(ParamList->Strings[ParamPos]);
	if(ptrVar == NULL)
	{
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
			AnsiString("Variable Unregistered : ") + ParamList->Strings[ParamPos]));
	}
	//READ VARIABLE
	else if(DDECmd.AnsiCompareIC("Read") == NULL)
	{
		//=============== INTERNAL REGISTERED VARIABLES ==============
		if(ptrVar->Name.AnsiCompareIC("FunctionList") == NULL)
		{
			ptrVar->Value = "";
			for(unsigned int x=0; x < Functions.size(); x++)
				ptrVar->Value = ptrVar->Value + Functions.at(x)->Name + " ";
			ptrVar->Value = DDECmd + " " + ptrVar->Name + " OK " + ptrVar->Value;
			ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmVariable, ptrVar->Value));
		}
		else if(ptrVar->Name.AnsiCompareIC("VariableList") == NULL)
		{
			ptrVar->Value = "";
			for(unsigned int x=0; x < Variables.size(); x++)
				ptrVar->Value = ptrVar->Value + Variables.at(x)->Name + " ";
			ptrVar->Value = DDECmd + " " + ptrVar->Name + " OK " + ptrVar->Value;
			ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmVariable, ptrVar->Value));
		}
		//============================================================

		else if(OnVariableRead)
		{
			//*** User Callback ***
			OnVariableRead(ptrVar->Name, ptrVar->Type, &(ptrVar->Value));
			VariableCheck(ptrVar, "Read"); //Check returned value
		}
		else
		{
			ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
				AnsiString("OnVariableRead() Event not implemented!")));
		}
	}
	else if(DDECmd.AnsiCompareIC("Write") == NULL)
	{
		if(OnVariableWrite)
		{
			if(ptrVar->ReadOnly == true)
			{
				ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
					AnsiString(ptrVar->Name) + " is write protected!"));
			}
			else
			{
				OnVariableWrite(ptrVar->Name, ptrVar->Type, &(ptrVar->Value));
				VariableCheck(ptrVar, "Write"); //Check returned value
			}
		}
		else
		{
			ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
				AnsiString("OnVariableWrite() Event not implemented!")));
		}
	}
	else //Keyword unknown (DDECmd)
	{
		//Raised Error for unhandled Function
		ResultBuffer->Add(FmtDDEMessage(AppName, DestApp, dmError,
			AnsiString("Unknown Variable Access Keyword : ") + DDECmd));
	}
}
//---------------------------------------------------------------------------
//###########################################################################
// CLASS : DDE Client
//###########################################################################
//---------------------------------------------------------------------------
int MDDEApp_Client::ObjectCount = NULL;
MErrorControl *(MDDEApp_Client::Err) = NULL;
//---------------------------------------------------------------------------
AnsiString __fastcall MDDEApp_Client::GetLibVersion(){ return _Version; }
MDDEApp_Client::MDDEApp_Client(TComponent *Owner)
{
	//Initialize Error Control
	ObjectCount++;
	if(Err == NULL)
	{
		Err = new MErrorControl("MDDEApp_Client");
		Err->DecodeErrorMsg = DecodeErrorMsg;
    }

	//Initialize Local Variable
	_Owner = Owner;
	_Wait_InLoop = false;
	Items.clear();
	ParamList = new TStringList;
	MsgBuffer = new TStringList;

	#ifndef COMPILER_BCB5
		ParamList->Delimiter = ' ';
		MsgBuffer->Delimiter = ' ';
    #endif

	DDETimer = new TTimer(Owner);
	DDETimer->Interval = 1000;
	DDETimer->Enabled = false;
	DDETimer->OnTimer = OnTimeout;

	//Register Client's Application Name
	AppName = ExtractFileName(ParamStr(0));
	AnsiString tExt = ExtractFileExt(ParamStr(0));
	AppName = AnsiReplaceStr(AppName, tExt, "");

	OnLinkClosed = NULL;
	OnServerOnline = NULL;
	OnSend = NULL;
	OnReceive_Raw = NULL;
	OnReceive_Filtered = NULL;
	OnFunctionReturn = NULL;
	OnDbgMsg = NULL;
}
//---------------------------------------------------------------------------
MDDEApp_Client::~MDDEApp_Client()
{
	DeleteAll();

	delete ParamList;
	delete MsgBuffer;
	delete DDETimer;

	ParamList = NULL;
	MsgBuffer = NULL;
	DDETimer = NULL;

	ObjectCount--;
	if(ObjectCount == NULL)
	{
		delete Err;
		Err = NULL;
    }

}
//---------------------------------------------------------------------------
AnsiString MDDEApp_Client::DecodeErrorMsg(int ERRORID, int STATUS)
{
	/************************************************************************
	 DESC	: Decode Error Message
	 ------------------------------------------------------------------------
	 NOTE:
	 - Handling User called function's error.
	 - DDE communication error not handled by ERRORCONTROL module
	************************************************************************/
	if(ERRORID == Err->ErrorID)
	{
		switch(STATUS)
		{
			case -1: return AnsiString("Unable to create client with [ %1 ].\nInvalid Application Extension [ %2 ]! Only EXE is allowed!");
			case -2: return AnsiString("Unable to create client with [ %1 ].\nCannot create multiple DDE Client with same service name [%2]!");

			case -10: return AnsiString("Invalid DDE Handle!");
			case -11: return AnsiString("Unable to establish link with Server [ %1 ]");
			case -12: return AnsiString("Unable to connect to Server [ %1 ], probably NON DDEApp Type Server");
			case -13: return AnsiString("Unable to execute DDE Macro");
			case -14: return AnsiString("Unable to execute command [ %1 ], server not connected!");

			case -20: return AnsiString("Unable to process multiple function call, DDEApp Client is busy!");
			case -21: return AnsiString("DDE Function Call Timeout!");

			case -50: return AnsiString("Error raised in DDE Application : [%1]\n\n%2");
			default: return AnsiString("Unknown Error!");
		}
	}
	else return AnsiString("Unknown Error. ERROR ID Not belong to this class!");

}
//---------------------------------------------------------------------------
// SECTION : Client Private Functions
//---------------------------------------------------------------------------
bool MDDEApp_Client::VerifyHandle(DDEHANDLE Handle)
{
	if(Handle == NULL) return false;

	//Verify ObjHandle
	for(unsigned int x=0; x < Items.size(); x++)
		if(Items.at(x) == (DDEClientItem *)Handle)
			return true;
	return false;
}
//---------------------------------------------------------------------------
bool MDDEApp_Client::DDEExecuteMacro(DDEClientItem *Sender, AnsiString Command)
{
	/************************************************************************
	 DESC	: Execute Macro
	 ------------------------------------------------------------------------
	 Wrapper function for TDdeClient::ExecuteMacro().
	 An OnSend() event is trigger before sending command to Server.
	************************************************************************/
	MsgBuffer->Clear();
	MsgBuffer->Text = Command;
	if(OnSend) OnSend((int) Sender, MsgBuffer);
	return Sender->DDEClient->ExecuteMacro(Command.c_str(), false);
}
//---------------------------------------------------------------------------
int MDDEApp_Client::WaitForEvent(WAITTYPE Type, DDEClientItem *Object, AnsiString *ReturnMessage)
{
	/************************************************************************
	 DESC	: Wait Loop
	 ------------------------------------------------------------------------
	 NOTE: Internal wait loop to wait for function call / variable access
	 complete / timeout which ever come first.
	 - WaitForEvent(): Start wait loop and wait timer.
	 - WaitComplete(): used in MessageReceived() to signal wait result.
	************************************************************************/
	if(ReturnMessage) *ReturnMessage = ""; //Clear Message Buffer (default)

	_Wait_Type = Type;
	_Wait_InLoop = true;
	_Wait_Timeout = false;
	_Wait_Status = NULL;
	DDETimer->Enabled = true;

	//Run Wait loop until signaled by WaitComplete() / Timeout
	DDETimer->Enabled = true;
	do { Application->ProcessMessages(); }
	while((_Wait_InLoop == true) && (_Wait_Timeout == false));
	DDETimer->Enabled = false;

	if(_Wait_Timeout) return Err->RaiseError(-21, "WaitForEvent");
	else
	{
		if(ReturnMessage) *ReturnMessage = _Wait_Message;
		return _Wait_Status;
	}
}
//---------------------------------------------------------------------------
bool MDDEApp_Client::WaitComplete(DDEClientItem *Object, int Status, AnsiString Message)
{
	if(_Wait_InLoop == false) return false;
	for(unsigned int x=0; x < Items.size(); x++)
	{
		if(Items.at(x) == Object)
		{
			_Wait_InLoop = false;
			_Wait_Status = Status;
			_Wait_Message = Message;
			return true;
		}
	}
	return false;
}
//---------------------------------------------------------------------------
// SECTION : Client Functions
//---------------------------------------------------------------------------
int MDDEApp_Client::Add(DDEHANDLE *Handle, AnsiString ApplicationName, bool AutoLaunch)
{
	/************************************************************************
	 DESC	: Add DDE Server
	 ------------------------------------------------------------------------
	 NOTE : Create DDE Client Object.
	 
	 INPUT:
	 AutoLaunch : Set to true if you want the application to start automatically 
	 	when connect() is called.
	************************************************************************/
	if(Handle) *Handle = NULL;

	//Verify Extension if Included. Only EXE is allowed
	AnsiString tExt = ExtractFileExt(ApplicationName);
	if((tExt.IsEmpty() == false) && (tExt.AnsiCompareIC("exe") == false))
	{
		Err->ErrParams->Add(ApplicationName);
		Err->ErrParams->Add(tExt);
		return Err->RaiseError(-1, "Add", Err->ErrParams);
	}

	//Extract service name from full ApplicationName path (without extension)
	AnsiString tServiceName = ExtractFileName(ApplicationName);
	tServiceName = AnsiReplaceStr(tServiceName, ".exe", "");

	//Validate Unique Service Name
	for(unsigned int x=0; x < Items.size(); x++)
	{
		if(Items.at(x)->Buffer_DDEService.AnsiCompareIC(tServiceName) == NULL)
		{
			Err->ErrParams->Add(ApplicationName);
			Err->ErrParams->Add(tServiceName);
			return Err->RaiseError(-2, "Add", Err->ErrParams);
		}
	}

	//Create DDE Client Entry (Unique Service Name)
	DDEClientItem *pDDEItem = new DDEClientItem;
	pDDEItem->DDEClient = new TDdeClientConv(_Owner);
	pDDEItem->ClientData = new TDdeClientItem(_Owner);
	pDDEItem->AppName = ApplicationName;

	//Setup DDEClientConv
	pDDEItem->DDEClient->Name = ""; //Must be NULL to support multiple object
	pDDEItem->DDEClient->FormatChars = true;
	pDDEItem->DDEClient->ConnectMode = ddeAutomatic;
	if(AutoLaunch == true) pDDEItem->DDEClient->ServiceApplication = ApplicationName;
	else pDDEItem->DDEClient->ServiceApplication = "";

	//Setup DDEClientData
	pDDEItem->ClientData->Name = ""; //Must be NULL to support multiple object
	pDDEItem->ClientData->DdeConv = pDDEItem->DDEClient;
	pDDEItem->ClientData->DdeItem = "ServerResult";

	//Store Local Variable
	pDDEItem->Buffer_DDEService = tServiceName;
	pDDEItem->Buffer_DDETopic = "DDEServer";
	pDDEItem->AutoLaunch = AutoLaunch;
	pDDEItem->Connected = false;

	//Assign Notify Event
	pDDEItem->DDEClient->OnOpen = LinkOpened;
	pDDEItem->DDEClient->OnClose = LinkClosed;
	pDDEItem->ClientData->OnChange = MessageReceived;

	Items.push_back(pDDEItem);

	if(Handle) *Handle = (int) pDDEItem;
	return NULL;
}
//---------------------------------------------------------------------------
void MDDEApp_Client::DeleteAll(void)
{
	for(unsigned int x=0; x < Items.size(); x++)
	{
		Disconnect((int) Items.at(x));
		Items.at(x)->DDEClient->OnClose = NULL; //Release handle to event
		delete Items.at(x);
		Items.at(x) = NULL;
	}
	Items.clear();
}
//---------------------------------------------------------------------------
int MDDEApp_Client::Connect(DDEHANDLE Handle)
{
	/************************************************************************
	 DESC	: Establish connection between Client and Server.
	************************************************************************/
	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, "Connect");
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;

	bool FlgLinkOK;
	pDDEItem->Connected = false;

	FlgLinkOK = pDDEItem->DDEClient->SetLink(pDDEItem->Buffer_DDEService,
					pDDEItem->Buffer_DDETopic);
	if(FlgLinkOK == false) return Err->RaiseError(-11, "Connect", pDDEItem->AppName);
	else return pDDEItem->Connected == true ? NULL : Err->RaiseError(-12, "Connect", pDDEItem->AppName);
}
//---------------------------------------------------------------------------
int MDDEApp_Client::Disconnect(DDEHANDLE Handle)
{
	/************************************************************************
	 DESC	: Disconnect Client from Server.
	************************************************************************/
	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, "Disconnect");
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;

	if(pDDEItem->Connected == false) return NULL;
	if(DDEExecuteMacro(pDDEItem, FmtDDEMessage(AppName, pDDEItem->DDEClient->DdeService,
		dmSystem, "Disconnect")) == false) return Err->RaiseError(-13, "Disconnect");

	pDDEItem->DDEClient->CloseLink();
	return NULL;
}
//---------------------------------------------------------------------------
int MDDEApp_Client::ShutDownServer(DDEHANDLE Handle)
{
	/************************************************************************
	 DESC	: Request server to shut down.
	************************************************************************/
	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, "ShutDownServer");
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;

	if(DDEExecuteMacro(pDDEItem, FmtDDEMessage(AppName, pDDEItem->DDEClient->DdeService,
		dmSystem, "Shutdown")) == false) return Err->RaiseError(-13, "ShutDownServer");
	return NULL;
}
//---------------------------------------------------------------------------
void MDDEApp_Client::ShutDownAllServer(void)
{
	for(unsigned int x=0; x < Items.size(); x++)
	{
		if(Items.at(x)->Connected == true)
			ShutDownServer((int) Items.at(x));
	}
}
//---------------------------------------------------------------------------
void MDDEApp_Client::GetServerList(TStringList *Servers, bool FullPath)
{
	Servers->Clear();
	if(FullPath == true)
	{
		for(unsigned int x=0; x < Items.size(); x++)
			Servers->Add(Items.at(x)->AppName);
	}
	else
	{
		for(unsigned int x=0; x < Items.size(); x++)
			Servers->Add(Items.at(x)->Buffer_DDEService);
	}
}
//---------------------------------------------------------------------------
int MDDEApp_Client::FunctionCall(DDEHANDLE Handle, AnsiString Command)
{
	static AnsiString tFuncName = "FunctionCall";
	if(_Wait_InLoop == true) return Err->RaiseError(-20, tFuncName);

	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, tFuncName);
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;

	if(pDDEItem->Connected == false) return Err->RaiseError(-14, tFuncName, Command);

	if(DDEExecuteMacro(pDDEItem, FmtDDEMessage(AppName, pDDEItem->DDEClient->DdeService,
		dmFunction, Command)) == false)  return Err->RaiseError(-13, tFuncName);

	return NULL;
}
//---------------------------------------------------------------------------
int MDDEApp_Client::FunctionCall(DDEHANDLE Handle, AnsiString Command,
	int *FunctionStatus, AnsiString *ReturnMessage)
{
	/************************************************************************
	 DESC	: Execute Function on Server.
	************************************************************************/
	static AnsiString tFuncName = "FunctionCall";
	int tStatus = FunctionCall(Handle, Command);
	if(tStatus != NULL) return tStatus;

	//Wait Loop
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;
	tStatus = WaitForEvent(wtFunction, pDDEItem, ReturnMessage);
	if(FunctionStatus) *FunctionStatus = tStatus;

	//Error Check
	if(tStatus == Err->GpStatus) return Err->GpStatus; //Internal Error
	else if(tStatus < NULL)
	{
		//DDE Application Error
		Err->ErrParams->Add(pDDEItem->Buffer_DDEService);
		Err->ErrParams->Add(*ReturnMessage);
		return Err->RaiseError(-50, tFuncName, Err->ErrParams);
	}
	return NULL;
}
//---------------------------------------------------------------------------
int MDDEApp_Client::VariableRead(DDEHANDLE Handle, AnsiString Variable, AnsiString *Value)
{
	if(Value) *Value = "";
	if(_Wait_InLoop == true) return Err->RaiseError(-20, "VariableRead");

	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, "VariableRead");
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;

	AnsiString tCommand = AnsiString("Read ") + Variable;
	if(DDEExecuteMacro(pDDEItem, FmtDDEMessage(AppName, pDDEItem->DDEClient->DdeService,
		dmVariable, tCommand)) == false)  return Err->RaiseError(-13, "VariableRead");

	return WaitForEvent(wtVariable, pDDEItem, Value);
}
//---------------------------------------------------------------------------
int MDDEApp_Client::VariableWrite(DDEHANDLE Handle, AnsiString Variable, AnsiString Value)
{
	if(_Wait_InLoop == true) return Err->RaiseError(-20, "VariableWrite");;

	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, "VariableWrite");
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;

	AnsiString tCommand = AnsiString("Write ") + Variable + " " + Value;
	if(DDEExecuteMacro(pDDEItem, FmtDDEMessage(AppName, pDDEItem->DDEClient->DdeService,
		dmVariable, tCommand)) == false)  return Err->RaiseError(-13, "VariableWrite");

	return WaitForEvent(wtVariable, pDDEItem, NULL);
}
//---------------------------------------------------------------------------
AnsiString MDDEApp_Client::GetServiceName(DDEHANDLE Handle)
{
	/************************************************************************
	 DESC	: Retreive Client's Service Name (Server's Execution File's Name.)
	************************************************************************/
	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, "GetServiceName");
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;

	return pDDEItem->Buffer_DDEService;
}
//---------------------------------------------------------------------------
/***************************************************************
 TITLE	: Get Application Location
 AUTHOR : MAI
 DATE   : 22/12/08
--------------------------------------------------------------
 DESCRIPTION:
 Retreive Client's Full Path and File Name
--------------------------------------------------------------
 HISTORY:
***************************************************************/
AnsiString MDDEApp_Client::GetApplicationLocation(DDEHANDLE Handle)
{
	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, "GetApplicationLocation");
	DDEClientItem *pDDEItem = (DDEClientItem *)Handle;

	return pDDEItem->AppName;
}
//---------------------------------------------------------------------------
bool MDDEApp_Client::GetConnectStatus(DDEHANDLE Handle)
{
	/************************************************************************
	 DESC	: Check Client connection status with server.
	************************************************************************/
	//Object Verification
	if(VerifyHandle(Handle) == false) return false;
	return ((DDEClientItem *)Handle)->Connected;
}
//---------------------------------------------------------------------------
AnsiString MDDEApp_Client::GetVersion(DDEHANDLE Handle)
{
	/************************************************************************
	 DESC	:  Return DDE Application Server's protocol version.
	 ------------------------------------------------------------------------
	 NOTE: To be used for version control.
	************************************************************************/
	//Object Verification
	if(VerifyHandle(Handle) == false) return Err->RaiseError(-10, "GetVersion");
	return ((DDEClientItem *)Handle)->Version;
}
//---------------------------------------------------------------------------
// SECTION : DDE Client Events
//---------------------------------------------------------------------------
void __fastcall MDDEApp_Client::OnTimeout(TObject *Sender)
{
	DDETimer->Enabled = false;
	if(_Wait_InLoop == true)
	{
		_Wait_InLoop = false;
		_Wait_Timeout = true;
	}
}
//---------------------------------------------------------------------------
void __fastcall MDDEApp_Client::LinkOpened(TObject *Sender)
{
	/************************************************************************
	 DESC	: Link Open Event
	 ------------------------------------------------------------------------
	 Attached to TDdeClientConv::OnOpen() to get notified when
	 client open link to server.
	************************************************************************/
	TDdeClientConv *pObj = (TDdeClientConv *)Sender;
	for(unsigned int x=0; x < Items.size(); x++)
	{
		if(pObj == Items.at(x)->DDEClient)
		{
			//Connect to Server Data
			Items.at(x)->ClientData->DdeItem = "ServerData";

            //Send Connect protocol if connection to DdeItem is established 
			if(Items.at(x)->ClientData->DdeItem.IsEmpty() == false)
			{
				DDEExecuteMacro(Items.at(x), FmtDDEMessage(AppName, pObj->DdeService,
					dmSystem, "Connect"));
			}
			return;
		}
	}
}
//---------------------------------------------------------------------------
void __fastcall MDDEApp_Client::LinkClosed(TObject *Sender)
{
	/************************************************************************
	 DESC	: Link Close Event
	 ------------------------------------------------------------------------
	 Attached to TDdeClientConv::OnClose() to get notified when
	 link between client and server clsoed. 
	************************************************************************/
	TDdeClientConv *pObj = (TDdeClientConv *)Sender;
	for(unsigned int x=0; x < Items.size(); x++)
	{
		if(Items.at(x) == NULL) continue; //Fix Invalid Memory access.
		if(pObj == Items.at(x)->DDEClient)
		{
			Items.at(x)->Connected = false;
			if(OnLinkClosed) OnLinkClosed((int) Items.at(x));
			return;
		}
	}
}
//---------------------------------------------------------------------------
void __fastcall MDDEApp_Client::MessageReceived(TObject *Sender)
{
	/************************************************************************
	 DESC	: Message Received Event
	 ------------------------------------------------------------------------
	 Attached to TDdeClintItem::OnChange() to get informed when 
	  message sent from Server to Client.
	************************************************************************/
	int tStatus;
	AnsiString tStatusStr;
	AnsiString tMessage;
	TDdeClientItem *pObj = (TDdeClientItem *)Sender;
	DDEClientItem *Selected = NULL;

	//Server Verification
	for(unsigned int x=0; x < Items.size(); x++)
		if(pObj == Items.at(x)->ClientData)
			Selected = Items.at(x);

	if(Selected == NULL) return;
	if(Selected->ClientData->Text.IsEmpty() == true) return;

	//PASS OVER TO USER
	if(OnReceive_Raw) OnReceive_Raw((int) Selected, Selected->ClientData->Lines);

	for(int y=0; y < pObj->Lines->Count; y++)
	{
		ParamList->Clear();
		#ifndef COMPILER_BCB5
			ParamList->DelimitedText = pObj->Lines->Strings[y];
		#else
			SetDelimitedText(pObj->Lines->Strings[y], ParamList, DELIMITER);
		#endif

		//Check for minimum param size
		if(ParamList->Count < 4) continue;

		// Message Protocol : <SRC> <DEST> DDE.<Type> <Command>
		SrcApp = ParamList->Strings[0];
		DestApp = ParamList->Strings[1];
		Keyword = ParamList->Strings[2];
		DDECmd = ParamList->Strings[3];

		//Client Verification
		if(DestApp != "_SYS_")
		{
			if(DestApp.AnsiCompareIC(AppName) != NULL) continue;
		}
		if(OnReceive_Filtered) OnReceive_Filtered((int) Selected, pObj->Lines->Strings[y]);

		switch(GetKeywordID(DDEKwRef, DDEKwRefSize, Keyword))
		{
			case dmSystem:
				//Connection Response from Server
				if(DDECmd.AnsiCompareIC("CONNECTION_OPEN") == NULL)
				{
					if(ParamList->Count == 5)
					{
						Selected->Version = ParamList->Strings[ParamPos];
						if(Selected->Version.IsEmpty() == false)
                        	Selected->Connected = true;
					}
				}
				else if(DDECmd.AnsiCompareIC("SERVER_OFFLINE") == NULL)
				{
					//Server Initiated Offline
					Selected->Connected = false;
					if(OnLinkClosed) OnLinkClosed((int)Selected);
				}
				else if(DDECmd.AnsiCompareIC("SERVER_ONLINE") == NULL)
				{
					//Server resume Onlined.
                	if(OnServerOnline) OnServerOnline((int)Selected);
                }
				break;

			case dmFunction:
				if(ParamList->Count < 5) continue;
				if(ParamList->Count < 6) tMessage = "";
				else tMessage = ParamList->Strings[ParamPos + 1];
				tStatus = ParamList->Strings[ParamPos].ToInt();

				if(WaitComplete(Selected, tStatus, tMessage) == false)
				{
					//Not in wait loop. Raise Event if implemented
					if(OnFunctionReturn) OnFunctionReturn((int)Selected, tStatus, tMessage);
				}
				break;

			case dmVariable:
				if(ParamList->Count < 7) continue;
				tStatusStr = ParamList->Strings[ParamPos + 1];
				if(tStatusStr.AnsiCompareIC("OK") == NULL) tStatus = NULL;
				else if(tStatusStr.AnsiCompareIC("ERROR") == NULL) tStatus = -10001;
				else if(tStatusStr.AnsiCompareIC("READONLY") == NULL) tStatus = -10002;

				//Compile Returned data in single strings
				for(unsigned int x=0; x < 6; x++)
					ParamList->Delete(0);
                {
					#ifndef COMPILER_BCB5
						tMessage = ParamList->DelimitedText;
					#else
						SetDelimitedText(tMessage, ParamList, DELIMITER);
					#endif
				}

				WaitComplete(Selected, tStatus, tMessage);
				break;

			case dmError:
				for(int x=0; x < ParamPos - 1; x++) ParamList->Delete(0); //Remove Protocol Header

				#ifndef COMPILER_BCB5
					WaitComplete(Selected, -10003, ParamList->DelimitedText);
				#else
					tMessage = GetDelimitedText(ParamList, DELIMITER);
					WaitComplete(Selected, -10003, tMessage);
				#endif
				break;

			case dmInfo:
				if(OnDbgMsg)
				{
					for(int x=0; x < ParamPos - 1; x++) ParamList->Delete(0); //Remove Protocol Header
					OnDbgMsg((int) Selected, ParamList->DelimitedText);
				}

		}
	}//for each line
}
//---------------------------------------------------------------------------
