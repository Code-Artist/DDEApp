//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("Forms_BCB6\ClientControl.cpp", FClientControl);
USEFORM("Forms_BCB6\ClientControl_Item.cpp", FClientControlItem);
USEFORM("Forms_BCB6\ClientMessages.cpp", FClientMessages);
USEFORM("Forms_BCB6\DDE_ControlPanel.cpp", FDDEControlPanel);
USEFORM("Main_BCB6.cpp", FDDEMain);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TFDDEMain), &FDDEMain);
                 Application->CreateForm(__classid(TFDDEControlPanel), &FDDEControlPanel);
                 Application->CreateForm(__classid(TFClientControl), &FClientControl);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
