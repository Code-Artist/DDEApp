﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeArtEng.ErrorManagement
{
    internal abstract class ErrorHandler
    {
        protected abstract string GetErrorMessage(object errorCode);
        public string Get(object errorCode) { return Get(errorCode, (string[])null); }
        public string Get(object errorCode, string argument) { return Get(errorCode, new string[] { argument }); }
        public string Get(object errorCode, string[] arguments)
        {
            string errorMessage = GetErrorMessage(errorCode);
            if(arguments != null)
            {
                //Replace arguments in error message
                string tFind = string.Empty;
                for(int x = 0; x < arguments.Length; x++)
                {
                    tFind = "%" + (x + 1).ToString();
                    errorMessage = errorMessage.Replace(tFind, arguments[x]);
                }
            }
            return errorMessage;
        }
    }
}
